package com.nova.scanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.PointF
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.util.Size
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors

/** Own camera: choose capture resolution, live edge detection, crop / perspective, filters, multi-page. */
class ProCameraActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlay: QuadOverlay
    private lateinit var crop: CropView
    private lateinit var camLayer: FrameLayout
    private lateinit var reviewLayer: LinearLayout
    private lateinit var countLabel: TextView
    private lateinit var resChip: TextView
    private lateinit var filterChip: TextView
    private lateinit var autoChip: TextView
    private lateinit var flashChip: TextView
    private lateinit var shutter: TextView
    private lateinit var keepBtn: TextView
    private lateinit var skipBtn: TextView

    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null
    private val analysisExec = Executors.newSingleThreadExecutor()
    private var cvOk = false
    private var autoDetect = true
    private var filter = 1
    private var flashOn = false
    private var lastAnalysis = 0L
    private val pages = ArrayList<EncodedPage>()
    private var reviewBmp: Bitmap? = null
    private var importMode = false
    private val importQueue = ArrayList<Uri>()
    private val filterNames = arrayOf("Original", "Magic color", "Grayscale", "B&W document")

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            startCamera()
        } else {
            toast("Camera permission is needed to scan")
            finish()
        }
    }

    private val importPicker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { list ->
        if (list.isEmpty()) {
            finish()
        } else {
            importQueue.addAll(list)
            nextImport()
        }
    }

    private val backCb = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            if (reviewLayer.visibility == View.VISIBLE) {
                discardReview()
            } else if (pages.isNotEmpty()) {
                AlertDialog.Builder(this@ProCameraActivity)
                    .setTitle("Discard ${pages.size} scanned page(s)?")
                    .setPositiveButton("Discard") { _, _ -> finish() }
                    .setNegativeButton("Keep scanning", null)
                    .show()
            } else {
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(this, backCb)
        cvOk = DocDetect.ready()
        importMode = intent.getBooleanExtra("import", false)
        buildUi()
        if (importMode) {
            camLayer.visibility = View.GONE
            importPicker.launch("image/*")
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onDestroy() {
        analysisExec.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI
    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        camLayer = FrameLayout(this)
        previewView = PreviewView(this)
        previewView.scaleType = PreviewView.ScaleType.FIT_CENTER
        camLayer.addView(previewView, FrameLayout.LayoutParams(MATCH, MATCH))
        overlay = QuadOverlay(this)
        camLayer.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.VERTICAL
        top.setBackgroundColor(Color.argb(120, 0, 0, 0))
        val (hdr, _) = headerRow("Scan") { onBackPressedDispatcher.onBackPressed() }
        top.addView(hdr)
        resChip = chip("") {
            Quality.showDialog(this, true) {
                updateChips()
                startCamera()
            }
        }
        filterChip = chip("") {
            filter = (filter + 1) % filterNames.size
            updateChips()
        }
        autoChip = chip("") {
            autoDetect = !autoDetect
            if (!autoDetect) overlay.quad = null
            overlay.invalidate()
            updateChips()
        }
        flashChip = chip("") {
            flashOn = !flashOn
            imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
            updateChips()
        }
        top.addView(chipScroll(listOf(resChip, filterChip, autoChip, flashChip)))
        camLayer.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER
        bottom.setBackgroundColor(Color.argb(120, 0, 0, 0))
        bottom.setPadding(dp(16), dp(12), dp(16), dp(20))
        countLabel = TextView(this)
        countLabel.setTextColor(Color.WHITE)
        countLabel.textSize = 14f
        countLabel.gravity = Gravity.CENTER
        bottom.addView(countLabel, LinearLayout.LayoutParams(0, WRAP, 1f))
        shutter = TextView(this)
        shutter.text = "\u25CF"
        shutter.textSize = 44f
        shutter.setTextColor(Color.WHITE)
        shutter.gravity = Gravity.CENTER
        shutter.background = roundBg(GREEN, 40)
        shutter.setOnClickListener { takePhoto() }
        bottom.addView(shutter, LinearLayout.LayoutParams(dp(78), dp(78)))
        val done = bigButton("Done \u2714", BLUE) { finishScan() }
        bottom.addView(done, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.leftMargin = dp(16) })
        camLayer.addView(bottom, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        root.addView(camLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        reviewLayer = LinearLayout(this)
        reviewLayer.orientation = LinearLayout.VERTICAL
        reviewLayer.setBackgroundColor(BG)
        reviewLayer.visibility = View.GONE
        val rt = TextView(this)
        rt.text = "Drag the green corners to fit the page"
        rt.setTextColor(Color.WHITE)
        rt.setPadding(dp(16), dp(14), dp(16), dp(8))
        reviewLayer.addView(rt)
        crop = CropView(this)
        reviewLayer.addView(crop, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val rb = LinearLayout(this)
        rb.orientation = LinearLayout.HORIZONTAL
        rb.setPadding(dp(8), dp(8), dp(8), dp(14))
        skipBtn = bigButton("\u2715 Retake", Color.parseColor("#374151")) { discardReview() }
        val rot = bigButton("\u21BB Rotate", Color.parseColor("#374151")) { rotateReview() }
        keepBtn = bigButton("\u2713 Keep", GREEN) { keepReview() }
        for (b in listOf(skipBtn, rot, keepBtn)) {
            val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            rb.addView(b, lp)
        }
        reviewLayer.addView(rb)
        root.addView(reviewLayer, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        updateChips()
    }

    private fun updateChips() {
        resChip.text = "\uD83D\uDCF7 " + Quality.camLabels[Quality.camIndex(this)].replace(" (device best)", " max")
        filterChip.text = "\uD83C\uDFA8 " + filterNames[filter]
        autoChip.text = "Auto-crop: " + (if (autoDetect && cvOk) "ON" else "OFF")
        flashChip.text = if (flashOn) "\u26A1 Flash ON" else "\u26A1 Flash off"
        countLabel.text = if (pages.isEmpty()) "No pages yet" else "${pages.size} page(s)"
    }

    // ---------------------------------------------------------------- camera
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = try {
                future.get()
            } catch (e: Exception) {
                toast("Camera failed to start")
                return@addListener
            }
            val ci = Quality.camIndex(this)
            val strategy = if (ci == 0) ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY
            else ResolutionStrategy(Size(Quality.camW[ci], Quality.camH[ci]), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
            val ratio = AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
            val preview = Preview.Builder()
                .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(ratio).build())
                .build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val capture = ImageCapture.Builder()
                .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(ratio).setResolutionStrategy(strategy).build())
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setFlashMode(if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF)
                .build()
            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(
                    ResolutionSelector.Builder().setAspectRatioStrategy(ratio)
                        .setResolutionStrategy(ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)).build()
                )
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(analysisExec) { proxy -> analyze(proxy) }
            try {
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture, analysis)
                imageCapture = capture
            } catch (e: Exception) {
                toast("Camera error: " + (e.message ?: ""))
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(img: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (!autoDetect || !cvOk || now - lastAnalysis < 220) return
            lastAnalysis = now
            val plane = img.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val w = img.width
            val h = img.height
            val bytes = ByteArray(buf.remaining())
            buf.get(bytes)
            val mat = Mat(h, w, CvType.CV_8UC1)
            if (rowStride == w) {
                mat.put(0, 0, bytes)
            } else {
                val row = ByteArray(w)
                for (y in 0 until h) {
                    System.arraycopy(bytes, y * rowStride, row, 0, w)
                    mat.put(y, 0, row)
                }
            }
            val rotated = Mat()
            when (img.imageInfo.rotationDegrees) {
                90 -> Core.rotate(mat, rotated, Core.ROTATE_90_CLOCKWISE)
                180 -> Core.rotate(mat, rotated, Core.ROTATE_180)
                270 -> Core.rotate(mat, rotated, Core.ROTATE_90_COUNTERCLOCKWISE)
                else -> mat.copyTo(rotated)
            }
            val q = DocDetect.findQuad(rotated)
            mat.release()
            rotated.release()
            runOnUiThread {
                overlay.quad = q
                overlay.invalidate()
            }
        } catch (e: Throwable) {
            // skip this frame
        } finally {
            img.close()
        }
    }

    private fun takePhoto() {
        val ic = imageCapture ?: return
        shutter.isEnabled = false
        val f = File(cacheDir, "cap_" + System.nanoTime() + ".jpg")
        ic.takePicture(
            ImageCapture.OutputFileOptions.Builder(f).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    loadForReview(Uri.fromFile(f), f)
                }

                override fun onError(e: ImageCaptureException) {
                    shutter.isEnabled = true
                    toast("Capture failed: " + (e.message ?: ""))
                }
            }
        )
    }

    // ---------------------------------------------------------------- review
    private fun loadForReview(uri: Uri, tmp: File?) {
        val detect = autoDetect && cvOk
        Thread {
            val bmp = ImageUtil.decode(applicationContext, uri, 4200)
            val q = if (bmp != null && detect) DocDetect.findQuadBitmap(bmp) else null
            tmp?.delete()
            runOnUiThread {
                shutter.isEnabled = true
                if (bmp == null) {
                    toast("Could not read the photo")
                    if (importMode) nextImport()
                } else {
                    showReview(bmp, q)
                }
            }
        }.start()
    }

    private fun showReview(b: Bitmap, q: Array<PointF>?) {
        reviewBmp = b
        crop.setImage(b, q)
        camLayer.visibility = View.GONE
        reviewLayer.visibility = View.VISIBLE
        skipBtn.text = if (importMode) "\u2715 Skip" else "\u2715 Retake"
    }

    private fun discardReview() {
        reviewBmp?.recycle()
        reviewBmp = null
        reviewLayer.visibility = View.GONE
        if (importMode) {
            if (importQueue.isEmpty()) finishScan() else nextImport()
        } else {
            camLayer.visibility = View.VISIBLE
        }
    }

    private fun rotateReview() {
        val b = reviewBmp ?: return
        val m = Matrix()
        m.postRotate(90f)
        val r = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
        if (r !== b) b.recycle()
        reviewBmp = r
        crop.setImage(r, null)
    }

    private fun applyFilter(b: Bitmap): Bitmap = when (filter) {
        1 -> Enhance.apply(b, EnhanceParams(mode = 1, sharpen = 30), 3600)
        2 -> Enhance.apply(b, EnhanceParams(mode = 2, sharpen = 30), 3600)
        3 -> Enhance.apply(b, EnhanceParams(mode = 3, sharpen = 20), 3600)
        else -> b
    }

    private fun keepReview() {
        val src = reviewBmp ?: return
        val q = crop.getQuad()
        keepBtn.isEnabled = false
        runBusy("Processing page\u2026", { _ ->
            val warped = DocDetect.warp(src, q)
            val out = applyFilter(warped)
            if (out !== warped) warped.recycle()
            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 92, bos)
            val e = EncodedPage(bos.toByteArray(), out.width, out.height)
            out.recycle()
            e
        }, { e ->
            keepBtn.isEnabled = true
            if (e != null) pages.add(e) else toast("Could not process this page")
            reviewBmp?.recycle()
            reviewBmp = null
            reviewLayer.visibility = View.GONE
            updateChips()
            if (importMode) {
                if (importQueue.isEmpty()) finishScan() else nextImport()
            } else {
                camLayer.visibility = View.VISIBLE
            }
        })
    }

    private fun nextImport() {
        if (importQueue.isEmpty()) {
            finishScan()
            return
        }
        val u = importQueue.removeAt(0)
        loadForReview(u, null)
    }

    // ---------------------------------------------------------------- finish
    private fun finishScan() {
        if (pages.isEmpty()) {
            toast("No pages scanned yet")
            if (importMode) finish()
            return
        }
        val list = ArrayList(pages)
        runBusy("Saving\u2026", { prog ->
            val resIdx = Quality.resIndex(this)
            val budget = Quality.budgetPerPage(this, list.size)
            val enc = ArrayList<EncodedPage>()
            list.forEachIndexed { i, pg ->
                prog("Optimizing page ${i + 1} / ${list.size}\u2026")
                val b = BitmapFactory.decodeByteArray(pg.jpeg, 0, pg.jpeg.size)
                if (b != null) {
                    enc.add(Quality.encodeBitmapScaled(b, resIdx, budget))
                    b.recycle()
                }
            }
            ScanStore.createFromPages(this, enc, PdfLayout(0f, 0f, 0f, 0), defaultName(System.currentTimeMillis()))
        }, { s ->
            if (s == null) {
                toast("Could not save the scan")
            } else {
                pages.clear()
                startActivity(Intent(this, DetailActivity::class.java).putExtra("id", s.id))
                finish()
            }
        })
    }
}
