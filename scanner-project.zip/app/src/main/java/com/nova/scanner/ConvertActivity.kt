package com.nova.scanner

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

class ConvResult(val files: List<File>, val kind: String, val scan: Scan?, val note: String?)

/** All document converters. mode: pdf2docx, pdf2xlsx, pdf2img, pdf2txt, docx2pdf, xlsx2pdf, txt2pdf, hub. */
class ConvertActivity : AppCompatActivity() {

    private var mode = "hub"
    private var src: File? = null
    private var srcName = "document"
    private var dpi = 200
    private var png = false
    private var engine = 0
    private lateinit var titleView: TextView
    private lateinit var fileInfo: TextView
    private lateinit var optionsBox: LinearLayout
    private lateinit var resultBox: LinearLayout
    private var result: ConvResult? = null

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = PdfCore.displayName(this, uri)
            val ok = when {
                mode.startsWith("pdf") -> name.lowercase().endsWith(".pdf")
                mode == "docx2pdf" -> name.lowercase().endsWith(".docx")
                mode == "xlsx2pdf" -> name.lowercase().endsWith(".xlsx")
                else -> true
            }
            if (!ok) {
                toast(
                    when (mode) {
                        "docx2pdf" -> "Please choose a .docx file (old .doc is not supported)"
                        "xlsx2pdf" -> "Please choose a .xlsx file (old .xls is not supported)"
                        else -> "Wrong file type"
                    }
                )
            } else {
                runBusy("Reading file\u2026", { _ ->
                    val f = File(PdfCore.workDir(this), "in_" + System.nanoTime() + "_" + safeName(name))
                    val input = contentResolver.openInputStream(uri)
                    if (input == null) null else {
                        input.use { i -> FileOutputStream(f).use { o -> i.copyTo(o) } }
                        f
                    }
                }, { f ->
                    if (f == null) {
                        toast("Could not read the file")
                    } else {
                        src = f
                        srcName = PdfCore.baseName(name)
                        fileInfo.text = name + "  \u2022  " + fmtSize(f.length())
                    }
                })
            }
        }
    }

    private val saveDocx = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    ) { uri -> copyTo(uri) }
    private val saveXlsx = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri -> copyTo(uri) }
    private val saveTxt = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri -> copyTo(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode") ?: "hub"
        engine = prefs().getInt("ocr_engine", 0).coerceIn(0, 2)
        buildUi()
        if (mode == "hub") hubDialog()
    }

    private fun titleFor(): String = when (mode) {
        "pdf2docx" -> "PDF \u2192 Word"
        "pdf2xlsx" -> "PDF \u2192 Excel"
        "pdf2img" -> "PDF \u2192 Images"
        "pdf2txt" -> "PDF \u2192 TXT"
        "docx2pdf" -> "Word \u2192 PDF"
        "xlsx2pdf" -> "Excel \u2192 PDF"
        "txt2pdf" -> "TXT \u2192 PDF"
        else -> "Convert"
    }

    private fun hubDialog() {
        val labels = arrayOf("PDF \u2192 Images (JPG / PNG)", "PDF \u2192 TXT", "TXT \u2192 PDF")
        val modes = arrayOf("pdf2img", "pdf2txt", "txt2pdf")
        chooseDialog("Convert", labels, -1) {
            mode = modes[it]
            src = null
            result = null
            rebuildOptions()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val (header, tv) = headerRow(titleFor()) { finish() }
        titleView = tv
        root.addView(header)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(8), dp(16), dp(8))
        body.addView(bigButton("\uD83D\uDCC2 Choose file", BLUE) {
            val types = when {
                mode.startsWith("pdf") -> arrayOf("application/pdf")
                mode == "txt2pdf" -> arrayOf("text/plain")
                else -> arrayOf("*/*")
            }
            picker.launch(types)
        })
        fileInfo = TextView(this)
        fileInfo.setTextColor(Color.WHITE)
        fileInfo.setPadding(0, dp(10), 0, dp(6))
        fileInfo.text = "No file chosen"
        body.addView(fileInfo)
        optionsBox = LinearLayout(this)
        optionsBox.orientation = LinearLayout.VERTICAL
        body.addView(optionsBox)
        body.addView(bigButton("\u25B6 Convert", GREEN) { convert() })
        resultBox = LinearLayout(this)
        resultBox.orientation = LinearLayout.VERTICAL
        resultBox.setPadding(0, dp(14), 0, 0)
        body.addView(resultBox)
        root.addView(body)
        setContentView(root)
        rebuildOptions()
    }

    private fun rebuildOptions() {
        titleView.text = titleFor()
        fileInfo.text = if (src == null) "No file chosen" else fileInfo.text
        optionsBox.removeAllViews()
        resultBox.removeAllViews()
        val chips = ArrayList<android.view.View>()
        if (mode == "pdf2img") {
            chips.add(chip("Quality: $dpi dpi") {
                chooseDialog("Image quality", arrayOf("Normal 150 dpi", "Good 200 dpi", "High 300 dpi"), if (dpi == 150) 0 else if (dpi == 200) 1 else 2) {
                    dpi = intArrayOf(150, 200, 300)[it]
                    rebuildOptions()
                }
            })
            chips.add(chip("Format: " + (if (png) "PNG" else "JPG")) {
                png = !png
                rebuildOptions()
            })
        }
        if (mode == "pdf2docx" || mode == "pdf2xlsx" || mode == "pdf2txt") {
            val names = arrayOf("English / numbers", "Bangla + English", "Cloud (handwriting)")
            chips.add(chip("Scanned pages OCR: " + names[engine]) {
                chooseDialog("OCR for scanned pages", names, engine) {
                    engine = it
                    if (it == 2 && prefs().getString("vision_key", "").isNullOrBlank()) toast("Add your Cloud key in OCR screen > Engine first")
                    rebuildOptions()
                }
            })
        }
        if (chips.isNotEmpty()) {
            optionsBox.addView(chipScroll(chips))
            val tip = TextView(this)
            tip.setTextColor(GRAY)
            tip.textSize = 12f
            tip.text = when (mode) {
                "pdf2img" -> "One image per page, saved to Pictures/NovaScanner."
                else -> "Text PDFs convert directly. Scanned (picture) pages are read with OCR automatically."
            }
            tip.setPadding(dp(6), 0, 0, dp(10))
            optionsBox.addView(tip)
        }
    }

    // ---------------------------------------------------------------- conversion
    private fun convert() {
        val f = src
        if (f == null) {
            toast("Choose a file first")
            return
        }
        resultBox.removeAllViews()
        val name = srcName
        runBusy("Converting\u2026", { p -> doConvert(f, name, p) }, { r ->
            if (r == null) {
                toast("Conversion failed. The file may be damaged or protected.")
            } else if (r.scan != null) {
                toast("Saved to My Documents")
                startActivity(Intent(this, ReaderActivity::class.java).putExtra("path", r.scan.pdf?.absolutePath).putExtra("title", r.scan.name))
            } else {
                result = r
                showResult(r)
            }
        })
    }

    private fun outDir(): File = File(cacheDir, "export/convert").also { it.mkdirs() }

    private fun doConvert(src: File, name: String, p: (String) -> Unit): ConvResult? {
        val base = safeName(name)
        when (mode) {
            "docx2pdf" -> {
                val out = PdfCore.newWorkFile(this, "d2p")
                if (!DocxPdf.render(src, out)) return null
                return ConvResult(emptyList(), "pdf", ScanStore.addPdf(this, out, "$name (Word)"), null)
            }
            "xlsx2pdf" -> {
                val out = PdfCore.newWorkFile(this, "x2p")
                if (!XlsxPdf.render(src, out)) return null
                return ConvResult(emptyList(), "pdf", ScanStore.addPdf(this, out, "$name (Excel)"), null)
            }
            "txt2pdf" -> {
                val bytes = src.readBytes()
                val text = try {
                    String(bytes, Charsets.UTF_8)
                } catch (e: Exception) {
                    String(bytes, Charsets.ISO_8859_1)
                }
                val out = PdfCore.newWorkFile(this, "t2p")
                if (!TextPdf.write(out, listOf(text))) return null
                return ConvResult(emptyList(), "pdf", ScanStore.addPdf(this, out, "$name (Text)"), null)
            }
        }
        // PDF inputs
        var runner: OcrRunner? = null
        var sess: PdfSession? = null
        var ocrError: String? = null
        val doc = PdfCore.load(src)
        try {
            val n = doc.numberOfPages
            val ocrFor: (Int) -> OcrResult? = { idx ->
                if (runner == null && ocrError == null) {
                    val r = OcrRunner(this, engine)
                    ocrError = r.prepare { m -> p(m) }
                    if (ocrError == null) runner = r
                }
                val r = runner
                if (r == null) {
                    null
                } else {
                    if (sess == null) sess = PdfSession(src)
                    val bmp = sess!!.render(idx, 2200)
                    if (bmp == null) null else try {
                        r.recognize(bmp)
                    } catch (e: Exception) {
                        null
                    } finally {
                        bmp.recycle()
                    }
                }
            }
            when (mode) {
                "pdf2docx", "pdf2xlsx" -> {
                    val pages = ArrayList<List<Block>>()
                    for (i in 0 until n) {
                        p("Page ${i + 1} / $n\u2026")
                        pages.add(PdfBlocks.page(doc, i) { idx -> ocrFor(idx)?.blocks ?: emptyList() })
                    }
                    val out = File(outDir(), "$base.${if (mode == "pdf2docx") "docx" else "xlsx"}")
                    val ok = if (mode == "pdf2docx") DocxBlocks.write(out, pages)
                    else XlsxWriter.write(out, pages.mapIndexed { i, b ->
                        val rows = XlsxWriter.rowsFromBlocks(b)
                        Pair("Page ${i + 1}", if (rows.isEmpty()) listOf(listOf("")) else rows)
                    })
                    if (!ok) return null
                    return ConvResult(listOf(out), if (mode == "pdf2docx") "docx" else "xlsx", null, ocrError)
                }
                "pdf2txt" -> {
                    val sb = StringBuilder()
                    for (i in 0 until n) {
                        p("Page ${i + 1} / $n\u2026")
                        var t = PdfText.plainText(PdfText.extractPage(doc, i))
                        if (t.isBlank()) t = ocrFor(i)?.text ?: ""
                        if (n > 1) sb.append("\n\n\u2500\u2500\u2500\u2500 Page ${i + 1} \u2500\u2500\u2500\u2500\n\n")
                        sb.append(t)
                    }
                    val out = File(outDir(), "$base.txt")
                    out.writeText(sb.toString().trim(), Charsets.UTF_8)
                    return ConvResult(listOf(out), "txt", null, ocrError)
                }
                "pdf2img" -> {
                    val s = PdfSession(src)
                    try {
                        val files = ArrayList<File>()
                        for (i in 0 until s.pageCount) {
                            p("Rendering page ${i + 1} / ${s.pageCount}\u2026")
                            val sz = s.pageSize(i)
                            val w = (sz.first / 72f * dpi).toInt().coerceIn(300, 4200)
                            val bmp = s.render(i, w) ?: continue
                            val f = File(outDir(), "${base}_page_${i + 1}." + (if (png) "png" else "jpg"))
                            FileOutputStream(f).use {
                                if (png) bmp.compress(Bitmap.CompressFormat.PNG, 100, it) else bmp.compress(Bitmap.CompressFormat.JPEG, 92, it)
                            }
                            bmp.recycle()
                            files.add(f)
                        }
                        return if (files.isEmpty()) null else ConvResult(files, "img", null, null)
                    } finally {
                        s.close()
                    }
                }
            }
            return null
        } finally {
            runner?.close()
            sess?.close()
            doc.close()
        }
    }

    // ---------------------------------------------------------------- results
    private fun showResult(r: ConvResult) {
        resultBox.removeAllViews()
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = 14f
        t.text = "\u2705 Done: " + r.files.size + " file(s)" + (if (r.note != null) "\n\u26A0 " + r.note else "")
        t.setPadding(0, 0, 0, dp(10))
        resultBox.addView(t)
        val row = ArrayList<android.view.View>()
        when (r.kind) {
            "docx" -> row.add(bigChip("\uD83D\uDCBE Save to phone") { saveDocx.launch(safeName(srcName) + ".docx") })
            "xlsx" -> row.add(bigChip("\uD83D\uDCBE Save to phone") { saveXlsx.launch(safeName(srcName) + ".xlsx") })
            "txt" -> row.add(bigChip("\uD83D\uDCBE Save to phone") { saveTxt.launch(safeName(srcName) + ".txt") })
            "img" -> row.add(bigChip("\uD83D\uDDBC Save to Gallery") { saveImages(r.files) })
        }
        row.add(bigChip("\uD83D\uDCE4 Share") { share(r) })
        resultBox.addView(chipScroll(row))
    }

    private fun bigChip(label: String, onClick: () -> Unit): TextView = bigButton(label, PURPLE, onClick)

    private fun copyTo(uri: Uri?) {
        val r = result ?: return
        if (uri == null || r.files.isEmpty()) return
        try {
            contentResolver.openOutputStream(uri)?.use { o -> r.files[0].inputStream().use { it.copyTo(o) } }
            toast("Saved")
        } catch (e: Exception) {
            toast("Could not save the file")
        }
    }

    private fun mimeOf(f: File): String = when (f.extension.lowercase()) {
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "txt" -> "text/plain"
        "png" -> "image/png"
        "jpg" -> "image/jpeg"
        else -> "*/*"
    }

    private fun share(r: ConvResult) {
        if (r.files.isEmpty()) return
        val uris = ArrayList<Uri>(r.files.map { Actions.uriFor(this, it) })
        val i: Intent
        if (uris.size == 1) {
            i = Intent(Intent.ACTION_SEND)
            i.putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            i = Intent(Intent.ACTION_SEND_MULTIPLE)
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        i.type = mimeOf(r.files[0])
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Share"))
    }

    private fun saveImages(files: List<File>) {
        if (Build.VERSION.SDK_INT < 29) {
            toast("On this Android version use Share and save from there")
            return
        }
        runBusy("Saving images\u2026", { _ ->
            var n = 0
            for (f in files) {
                try {
                    val cv = ContentValues()
                    cv.put(MediaStore.Images.Media.DISPLAY_NAME, f.name)
                    cv.put(MediaStore.Images.Media.MIME_TYPE, mimeOf(f))
                    cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NovaScanner")
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    if (uri != null) {
                        contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                        n++
                    }
                } catch (e: Exception) {
                    // skip
                }
            }
            n
        }, { n -> toast((n ?: 0).toString() + " image(s) saved to Pictures/NovaScanner") })
    }
}
