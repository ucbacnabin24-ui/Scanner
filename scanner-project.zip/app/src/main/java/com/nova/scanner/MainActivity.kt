package com.nova.scanner

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult

class MainActivity : AppCompatActivity() {

    private val bg = Color.parseColor("#121212")
    private val green = Color.parseColor("#16A34A")
    private val gray = Color.parseColor("#9CA3AF")

    private val scans = ArrayList<Scan>()
    private lateinit var adapter: ScanAdapter
    private lateinit var empty: TextView
    private var busy: AlertDialog? = null

    private val scanLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            if (r.resultCode == RESULT_OK) {
                val res = GmsDocumentScanningResult.fromActivityResultIntent(r.data)
                if (res != null) {
                    val uris = res.pages?.map { it.imageUri } ?: emptyList()
                    val pdfUri = res.pdf?.uri
                    saveScannerResult(uris, pdfUri)
                }
            }
        }

    private val pickImages =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            if (uris.isNotEmpty()) askQuality(uris)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)

        val title = TextView(this)
        title.text = "Nova Scanner"
        title.textSize = 24f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        title.setPadding(dp(18), dp(16), dp(18), dp(8))
        root.addView(title)

        val frame = FrameLayout(this)
        val rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = ScanAdapter(scans, { open(it) }, { menu(it) })
        rv.adapter = adapter
        frame.addView(rv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        empty = TextView(this)
        empty.text = "No scans yet.\nTap  \uD83D\uDCF7 Scan  to start."
        empty.setTextColor(gray)
        empty.textSize = 16f
        empty.gravity = Gravity.CENTER
        frame.addView(empty, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(12), dp(8), dp(12), dp(12))
        val scanBtn = bigButton("\uD83D\uDCF7  Scan", green) { startScan() }
        val imgBtn = bigButton("\uD83D\uDDBC  Images \u2192 PDF", Color.parseColor("#2563EB")) { pickImages.launch("image/*") }
        val lp1 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp1.rightMargin = dp(6)
        val lp2 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp2.leftMargin = dp(6)
        bar.addView(scanBtn, lp1)
        bar.addView(imgBtn, lp2)
        root.addView(bar)

        setContentView(root)
    }

    private fun bigButton(label: String, color: Int, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 16f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(12), dp(16), dp(12), dp(16))
        t.background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(14).toFloat()
        }
        t.setOnClickListener { onClick() }
        return t
    }

    private fun refresh() {
        scans.clear()
        scans.addAll(ScanStore.list(this))
        adapter.notifyDataSetChanged()
        empty.visibility = if (scans.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun open(s: Scan) {
        startActivity(Intent(this, DetailActivity::class.java).putExtra("id", s.id))
    }

    private fun menu(s: Scan) {
        AlertDialog.Builder(this)
            .setTitle(s.name)
            .setItems(arrayOf("Open", "Share", "Rename", "Delete")) { _, i ->
                when (i) {
                    0 -> open(s)
                    1 -> Actions.shareDialog(this, s)
                    2 -> Actions.rename(this, s) { refresh() }
                    3 -> Actions.delete(this, s) { refresh() }
                }
            }
            .show()
    }

    // ---------------------------------------------------------------- scanning
    private fun startScan() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setResultFormats(
                GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                GmsDocumentScannerOptions.RESULT_FORMAT_PDF
            )
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options)
            .getStartScanIntent(this)
            .addOnSuccessListener { sender ->
                scanLauncher.launch(IntentSenderRequest.Builder(sender).build())
            }
            .addOnFailureListener { e ->
                toast("Scanner not available: " + (e.message ?: "unknown error"))
            }
    }

    private fun showBusy(msg: String) {
        busy = AlertDialog.Builder(this).setMessage(msg).setCancelable(false).show()
    }

    private fun hideBusy() {
        busy?.dismiss()
        busy = null
    }

    private fun saveScannerResult(uris: List<Uri>, pdfUri: Uri?) {
        showBusy("Saving scan\u2026")
        Thread {
            val s = ScanStore.createFromScanner(applicationContext, uris, pdfUri)
            runOnUiThread {
                hideBusy()
                refresh()
                if (s != null) open(s) else toast("Could not save the scan")
            }
        }.start()
    }

    // ---------------------------------------------------------------- images -> pdf
    private fun askQuality(uris: List<Uri>) {
        val labels = arrayOf(
            "Normal  (small file, good for sharing)",
            "High  (sharp text)",
            "Maximum  (largest file, best quality)"
        )
        val maxLong = intArrayOf(1654, 2480, 3508)
        val quality = intArrayOf(80, 90, 95)
        AlertDialog.Builder(this)
            .setTitle("PDF / image quality")
            .setItems(labels) { _, i ->
                showBusy("Creating PDF\u2026")
                Thread {
                    val s = ScanStore.createFromImages(applicationContext, uris, maxLong[i], quality[i])
                    runOnUiThread {
                        hideBusy()
                        refresh()
                        if (s != null) open(s) else toast("Could not create PDF")
                    }
                }.start()
            }
            .show()
    }
}

class ScanAdapter(
    private val items: List<Scan>,
    private val onClick: (Scan) -> Unit,
    private val onLong: (Scan) -> Unit
) : RecyclerView.Adapter<ScanAdapter.VH>() {

    class VH(
        val root: LinearLayout,
        val thumb: ImageView,
        val title: TextView,
        val sub: TextView
    ) : RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context
        val root = LinearLayout(c)
        root.orientation = LinearLayout.HORIZONTAL
        root.gravity = Gravity.CENTER_VERTICAL
        root.setPadding(c.dp(14), c.dp(8), c.dp(14), c.dp(8))
        root.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        val thumb = ImageView(c)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.setBackgroundColor(Color.parseColor("#262626"))
        root.addView(thumb, LinearLayout.LayoutParams(c.dp(72), c.dp(92)))

        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(c.dp(14), 0, 0, 0)
        val title = TextView(c)
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        title.maxLines = 2
        title.ellipsize = TextUtils.TruncateAt.END
        val sub = TextView(c)
        sub.setTextColor(Color.parseColor("#9CA3AF"))
        sub.textSize = 12f
        sub.setPadding(0, c.dp(4), 0, 0)
        col.addView(title)
        col.addView(sub)
        root.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return VH(root, thumb, title, sub)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val s = items[position]
        h.title.text = s.name
        val n = s.pages.size
        val size = s.pdf?.length() ?: 0L
        h.sub.text = "$n page" + (if (n == 1) "" else "s") + "  \u2022  " + fmtDate(s.id) +
            (if (size > 0) "  \u2022  PDF " + fmtSize(size) else "")
        val first = s.pages.firstOrNull()
        if (first != null) Thumbs.load(h.root.context, first, h.thumb, 300) else h.thumb.setImageDrawable(null)
        h.root.setOnClickListener { onClick(s) }
        h.root.setOnLongClickListener {
            onLong(s)
            true
        }
    }
}
