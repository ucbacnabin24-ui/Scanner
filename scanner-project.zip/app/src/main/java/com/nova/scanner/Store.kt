package com.nova.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.util.LruCache
import android.widget.ImageView
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max

data class Scan(val id: Long, val dir: File, val name: String, val pages: List<File>, val pdf: File?)

object ScanStore {
    private fun root(ctx: Context): File = File(ctx.filesDir, "scans").also { it.mkdirs() }

    fun list(ctx: Context): List<Scan> {
        val dirs = root(ctx).listFiles() ?: return emptyList()
        return dirs.filter { it.isDirectory }.mapNotNull { load(it) }.sortedByDescending { it.id }
    }

    fun find(ctx: Context, id: Long): Scan? = load(File(root(ctx), id.toString()))

    private fun load(dir: File): Scan? {
        val id = dir.name.toLongOrNull() ?: return null
        val pages = (dir.listFiles() ?: emptyArray())
            .filter { it.name.startsWith("page_") && it.name.endsWith(".jpg") }
            .sortedBy { it.name }
        val pdf = File(dir, "doc.pdf").takeIf { it.exists() }
        if (pages.isEmpty() && pdf == null) return null
        val nf = File(dir, "name.txt")
        val name = if (nf.exists()) nf.readText().trim() else ""
        return Scan(id, dir, name.ifEmpty { defaultName(id) }, pages, pdf)
    }

    private fun copy(ctx: Context, src: Uri, dst: File) {
        val input = ctx.contentResolver.openInputStream(src) ?: throw IOException("Cannot open $src")
        input.use { i -> FileOutputStream(dst).use { o -> i.copyTo(o) } }
    }

    /** Save the result coming from the ML Kit document scanner. */
    fun createFromScanner(ctx: Context, pageUris: List<Uri>, pdfUri: Uri?): Scan? {
        val id = System.currentTimeMillis()
        val dir = File(root(ctx), id.toString())
        dir.mkdirs()
        try {
            pageUris.forEachIndexed { i, u -> copy(ctx, u, File(dir, String.format(Locale.US, "page_%03d.jpg", i + 1))) }
            if (pdfUri != null) copy(ctx, pdfUri, File(dir, "doc.pdf"))
            File(dir, "name.txt").writeText(defaultName(id))
            // no PDF returned? build one from the pages
            if (pdfUri == null && pageUris.isNotEmpty()) {
                val jpgs = dir.listFiles { f -> f.name.startsWith("page_") }!!.sortedBy { it.name }.mapNotNull { f ->
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(f.absolutePath, o)
                    if (o.outWidth > 0) Triple(f.readBytes(), o.outWidth, o.outHeight) else null
                }
                MiniPdf.write(File(dir, "doc.pdf"), jpgs)
            }
        } catch (e: Exception) {
            dir.deleteRecursively()
            return null
        }
        return load(dir)
    }

    /** Convert gallery images to a scan (JPG pages + PDF) at the chosen quality. */
    fun createFromImages(ctx: Context, uris: List<Uri>, maxLong: Int, jpegQuality: Int): Scan? {
        val id = System.currentTimeMillis()
        val dir = File(root(ctx), id.toString())
        dir.mkdirs()
        try {
            val jpgs = ArrayList<Triple<ByteArray, Int, Int>>()
            for (u in uris) {
                val bmp = ImageUtil.decode(ctx, u, maxLong) ?: continue
                val bos = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, jpegQuality, bos)
                val data = bos.toByteArray()
                File(dir, String.format(Locale.US, "page_%03d.jpg", jpgs.size + 1)).writeBytes(data)
                jpgs.add(Triple(data, bmp.width, bmp.height))
                bmp.recycle()
            }
            if (jpgs.isEmpty() || !MiniPdf.write(File(dir, "doc.pdf"), jpgs)) {
                dir.deleteRecursively()
                return null
            }
            File(dir, "name.txt").writeText(defaultName(id))
        } catch (e: Exception) {
            dir.deleteRecursively()
            return null
        }
        return load(dir)
    }

    fun rename(s: Scan, newName: String) {
        File(s.dir, "name.txt").writeText(newName.trim())
    }

    fun delete(s: Scan) {
        s.dir.deleteRecursively()
    }
}

object ImageUtil {
    private fun exifRotation(input: InputStream): Int = try {
        when (ExifInterface(input).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }

    /** Decode, fix rotation, limit the long edge to [maxLong] pixels, flatten onto white. */
    fun decode(ctx: Context, uri: Uri, maxLong: Int): Bitmap? {
        val cr = ctx.contentResolver
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxLong * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val rot = cr.openInputStream(uri)?.use { exifRotation(it) } ?: 0

            val longest = max(bmp.width, bmp.height)
            val scale = if (longest > maxLong) maxLong.toFloat() / longest else 1f
            if (rot != 0 || scale != 1f) {
                val m = Matrix()
                if (rot != 0) m.postRotate(rot.toFloat())
                if (scale != 1f) m.postScale(scale, scale)
                val t = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (t !== bmp) bmp.recycle()
                bmp = t
            }
            val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
            val c = Canvas(flat)
            c.drawColor(Color.WHITE)
            c.drawBitmap(bmp, 0f, 0f, null)
            bmp.recycle()
            return flat
        } catch (e: Exception) {
            return null
        } catch (e: OutOfMemoryError) {
            return null
        }
    }
}

/** Minimal PDF writer: embeds the JPEG bytes directly, so files stay small and sharp. */
object MiniPdf {
    private class Counter(val os: OutputStream) {
        var pos = 0L
        fun w(b: ByteArray) {
            os.write(b)
            pos += b.size
        }
        fun w(s: String) = w(s.toByteArray(Charsets.ISO_8859_1))
    }

    fun write(out: File, pages: List<Triple<ByteArray, Int, Int>>): Boolean {
        if (pages.isEmpty()) return false
        return try {
            FileOutputStream(out).use { fos ->
                val c = Counter(fos.buffered())
                val n = pages.size
                val total = 2 + 3 * n
                val offs = LongArray(total + 1)
                fun begin(num: Int) {
                    offs[num] = c.pos
                    c.w("$num 0 obj\n")
                }
                c.w("%PDF-1.4\n")
                begin(1)
                c.w("<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
                begin(2)
                val kids = (0 until n).joinToString(" ") { "${3 + it * 3} 0 R" }
                c.w("<< /Type /Pages /Kids [$kids] /Count $n >>\nendobj\n")
                for (i in 0 until n) {
                    val (data, w, h) = pages[i]
                    val b = 3 + i * 3
                    val k = 842f / max(w, h)
                    val pw = String.format(Locale.US, "%.2f", w * k)
                    val ph = String.format(Locale.US, "%.2f", h * k)
                    begin(b)
                    c.w("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $pw $ph] /Resources << /XObject << /Im0 ${b + 1} 0 R >> >> /Contents ${b + 2} 0 R >>\nendobj\n")
                    begin(b + 1)
                    c.w("<< /Type /XObject /Subtype /Image /Width $w /Height $h /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${data.size} >>\nstream\n")
                    c.w(data)
                    c.w("\nendstream\nendobj\n")
                    val content = "q $pw 0 0 $ph 0 0 cm /Im0 Do Q"
                    begin(b + 2)
                    c.w("<< /Length ${content.length} >>\nstream\n$content\nendstream\nendobj\n")
                }
                val xref = c.pos
                c.w("xref\n0 ${total + 1}\n")
                c.w("0000000000 65535 f \n")
                for (k in 1..total) c.w(String.format(Locale.US, "%010d 00000 n \n", offs[k]))
                c.w("trailer\n<< /Size ${total + 1} /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n")
                c.os.flush()
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(2)

    fun load(ctx: Context, f: File, iv: ImageView, maxLong: Int) {
        val key = f.absolutePath + "@" + f.lastModified() + "@" + maxLong
        iv.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        val app = ctx.applicationContext
        pool.execute {
            val bmp = ImageUtil.decode(app, Uri.fromFile(f), maxLong)
            if (bmp != null) {
                cache.put(key, bmp)
                iv.post { if (iv.tag == key) iv.setImageBitmap(bmp) }
            }
        }
    }
}
