package com.nova.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.util.LruCache
import android.widget.ImageView
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class EncodedPage(val jpeg: ByteArray, val w: Int, val h: Int)

/** pageW/pageH = 0 means "page = image size". orient: 0 auto, 1 portrait, 2 landscape. */
class PdfLayout(val pageW: Float, val pageH: Float, val margin: Float, val orient: Int)

class PdfPageSpec(
    val jpeg: ByteArray, val imgW: Int, val imgH: Int,
    val pageW: Float, val pageH: Float,
    val x: Float, val y: Float, val dw: Float, val dh: Float
)

data class Scan(
    val id: Long,
    val dir: File,
    val name: String,
    val folder: String,
    val pages: List<File>,
    val pdf: File?,
    val pageCountMeta: Int = 0,
    val thumb: File? = null
) {
    val sizeBytes: Long
        get() = pdf?.length() ?: pages.sumOf { it.length() }
    val pageCount: Int
        get() = if (pages.isNotEmpty()) pages.size else pageCountMeta
    /** PDF-only documents (merged / edited / converted) have no page images. */
    val pdfOnly: Boolean
        get() = pages.isEmpty()
    val previewFile: File?
        get() = pages.firstOrNull() ?: thumb
}

object Folders {
    private fun file(ctx: Context) = File(ctx.filesDir, "folders.txt")

    fun list(ctx: Context): List<String> {
        val f = file(ctx)
        if (!f.exists()) return emptyList()
        return f.readLines().map { it.trim() }.filter { it.isNotEmpty() }.distinct()
            .sortedBy { it.lowercase() }
    }

    private fun save(ctx: Context, l: List<String>) {
        file(ctx).writeText(l.joinToString("\n"))
    }

    fun add(ctx: Context, name: String): Boolean {
        val n = name.trim()
        if (n.isEmpty()) return false
        val l = list(ctx).toMutableList()
        if (l.any { it.equals(n, true) }) return true
        l.add(n)
        save(ctx, l)
        return true
    }

    fun rename(ctx: Context, old: String, new: String) {
        val n = new.trim()
        if (n.isEmpty()) return
        save(ctx, list(ctx).map { if (it == old) n else it })
        for (s in ScanStore.list(ctx)) if (s.folder == old) ScanStore.move(s, n)
    }

    fun remove(ctx: Context, name: String) {
        save(ctx, list(ctx).filter { it != name })
        for (s in ScanStore.list(ctx)) if (s.folder == name) ScanStore.move(s, "")
    }
}

object ScanStore {
    private fun root(ctx: Context): File = File(ctx.filesDir, "scans").also { it.mkdirs() }

    private fun newDir(ctx: Context): Pair<Long, File> {
        var id = System.currentTimeMillis()
        while (File(root(ctx), id.toString()).exists()) id++
        val d = File(root(ctx), id.toString())
        d.mkdirs()
        return Pair(id, d)
    }

    fun list(ctx: Context): List<Scan> {
        val dirs = root(ctx).listFiles() ?: return emptyList()
        return dirs.filter { it.isDirectory }.mapNotNull { load(it) }.sortedByDescending { it.id }
    }

    fun find(ctx: Context, id: Long): Scan? = load(File(root(ctx), id.toString()))

    private fun load(dir: File): Scan? {
        val id = dir.name.toLongOrNull() ?: return null
        val pages = (dir.listFiles() ?: emptyArray())
            .filter { it.name.startsWith("page_") && it.name.endsWith(".jpg") }
            .sortedBy { it.name }
        val pdf = File(dir, "doc.pdf").takeIf { it.exists() }
        if (pages.isEmpty() && pdf == null) return null
        val nf = File(dir, "name.txt")
        val name = if (nf.exists()) nf.readText().trim() else ""
        val ff = File(dir, "folder.txt")
        val folder = if (ff.exists()) ff.readText().trim() else ""
        val pc = File(dir, "pages.txt")
        val meta = if (pc.exists()) (pc.readText().trim().toIntOrNull() ?: 0) else 0
        val th = File(dir, "thumb.jpg").takeIf { it.exists() }
        return Scan(id, dir, name.ifEmpty { defaultName(id) }, folder, pages, pdf, meta, th)
    }

    private fun copy(ctx: Context, src: Uri, dst: File) {
        val input = ctx.contentResolver.openInputStream(src) ?: throw IOException("Cannot open $src")
        input.use { i -> FileOutputStream(dst).use { o -> i.copyTo(o) } }
    }

    /** Save the result coming from the ML Kit document scanner. */
    fun createFromScanner(ctx: Context, pageUris: List<Uri>, pdfUri: Uri?): Scan? {
        val (id, dir) = newDir(ctx)
        try {
            pageUris.forEachIndexed { i, u ->
                copy(ctx, u, File(dir, String.format(Locale.US, "page_%03d.jpg", i + 1)))
            }
            if (pdfUri != null) copy(ctx, pdfUri, File(dir, "doc.pdf"))
            File(dir, "name.txt").writeText(defaultName(id))
            if (pdfUri == null && pageUris.isNotEmpty()) {
                val jpgs = dir.listFiles { f -> f.name.startsWith("page_") }!!
                    .sortedBy { it.name }
                    .mapNotNull { f ->
                        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(f.absolutePath, o)
                        if (o.outWidth > 0) EncodedPage(f.readBytes(), o.outWidth, o.outHeight) else null
                    }
                MiniPdf.writeSpecs(File(dir, "doc.pdf"), MiniPdf.layout(jpgs, PdfLayout(0f, 0f, 0f, 0)))
            }
        } catch (e: Exception) {
            dir.deleteRecursively()
            return null
        }
        return load(dir)
    }

    /** Create a scan (JPG pages + laid-out PDF) from already encoded JPEG pages. */
    fun createFromPages(ctx: Context, pages: List<EncodedPage>, lay: PdfLayout, name: String?): Scan? {
        if (pages.isEmpty()) return null
        val (id, dir) = newDir(ctx)
        try {
            pages.forEachIndexed { i, p ->
                File(dir, String.format(Locale.US, "page_%03d.jpg", i + 1)).writeBytes(p.jpeg)
            }
            if (!MiniPdf.writeSpecs(File(dir, "doc.pdf"), MiniPdf.layout(pages, lay))) {
                dir.deleteRecursively()
                return null
            }
            File(dir, "name.txt").writeText(name ?: defaultName(id).replace("Scan", "PDF"))
        } catch (e: Exception) {
            dir.deleteRecursively()
            return null
        }
        return load(dir)
    }

    /** Add a finished PDF file (merged, edited, converted ...) to the library. */
    fun addPdf(ctx: Context, src: File, name: String, folder: String = ""): Scan? {
        val (_, dir) = newDir(ctx)
        try {
            val dst = File(dir, "doc.pdf")
            src.copyTo(dst, overwrite = true)
            File(dir, "name.txt").writeText(name)
            if (folder.isNotEmpty()) File(dir, "folder.txt").writeText(folder)
            var sess: PdfSession? = null
            try {
                sess = PdfSession(dst)
                File(dir, "pages.txt").writeText(sess.pageCount.toString())
                val bmp = sess.render(0, 360)
                if (bmp != null) {
                    FileOutputStream(File(dir, "thumb.jpg")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
                    bmp.recycle()
                }
            } finally {
                sess?.close()
            }
        } catch (e: Exception) {
            dir.deleteRecursively()
            return null
        }
        return load(dir)
    }

    /** Re-encode a freshly scanned document to the quality chosen on the home screen. */
    fun applyQuality(ctx: Context, s: Scan): Scan {
        if (Quality.isOriginal(ctx) || s.pages.isEmpty()) return s
        val n = s.pages.size
        val budget = Quality.budgetPerPage(ctx, n)
        val enc = ArrayList<EncodedPage>()
        for (f in s.pages) {
            val e = Quality.encodeUri(ctx, Uri.fromFile(f), 0, Quality.resIndex(ctx), budget) ?: return s
            enc.add(e)
        }
        enc.forEachIndexed { i, p -> s.pages[i].writeBytes(p.jpeg) }
        MiniPdf.writeSpecs(File(s.dir, "doc.pdf"), MiniPdf.layout(enc, PdfLayout(0f, 0f, 0f, 0)))
        return load(s.dir) ?: s
    }

    fun rename(s: Scan, newName: String) {
        File(s.dir, "name.txt").writeText(newName.trim())
    }

    fun move(s: Scan, folder: String) {
        val f = File(s.dir, "folder.txt")
        if (folder.isEmpty()) f.delete() else f.writeText(folder)
    }

    fun delete(s: Scan) {
        s.dir.deleteRecursively()
    }
}

object ImageUtil {
    private fun exifRotation(input: InputStream): Int = try {
        when (ExifInterface(input).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }

    /**
     * Decode with memory-safe sub-sampling, fix EXIF rotation, apply [extraRot],
     * fit inside [maxLong] x [maxShort] (never upscales), flatten transparency onto white.
     */
    fun decode(ctx: Context, uri: Uri, maxLong: Int, maxShort: Int = Int.MAX_VALUE, extraRot: Int = 0): Bitmap? {
        val cr = ctx.contentResolver
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            val longEdge = max(bounds.outWidth, bounds.outHeight)
            var sample = 1
            while (longEdge / (sample * 2) >= maxLong) sample *= 2
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val exif = cr.openInputStream(uri)?.use { exifRotation(it) } ?: 0
            val rot = (exif + extraRot) % 360

            val longest = max(bmp.width, bmp.height).toFloat()
            val shortest = min(bmp.width, bmp.height).toFloat()
            val scale = min(1f, min(maxLong / longest, maxShort / shortest))
            if (rot != 0 || scale < 0.999f) {
                val m = Matrix()
                if (rot != 0) m.postRotate(rot.toFloat())
                if (scale < 0.999f) m.postScale(scale, scale)
                val t = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (t !== bmp) bmp.recycle()
                bmp = t
            }
            if (bmp.hasAlpha()) {
                val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                val c = Canvas(flat)
                c.drawColor(Color.WHITE)
                c.drawBitmap(bmp, 0f, 0f, null)
                bmp.recycle()
                bmp = flat
            }
            return bmp
        } catch (e: Exception) {
            return null
        } catch (e: OutOfMemoryError) {
            return null
        }
    }
}

/** Minimal PDF writer: embeds JPEG bytes directly so files stay small and sharp. */
object MiniPdf {
    private class Counter(val os: OutputStream) {
        var pos = 0L
        fun w(b: ByteArray) {
            os.write(b)
            pos += b.size
        }
        fun w(s: String) = w(s.toByteArray(Charsets.ISO_8859_1))
    }

    fun layout(pages: List<EncodedPage>, lay: PdfLayout): List<PdfPageSpec> {
        val out = ArrayList<PdfPageSpec>()
        for (p in pages) {
            if (lay.pageW <= 0f || lay.pageH <= 0f) {
                val k = 842f / max(p.w, p.h)
                val pw = p.w * k
                val ph = p.h * k
                out.add(PdfPageSpec(p.jpeg, p.w, p.h, pw, ph, 0f, 0f, pw, ph))
            } else {
                val a = min(lay.pageW, lay.pageH)
                val b = max(lay.pageW, lay.pageH)
                val landscape = when (lay.orient) {
                    1 -> false
                    2 -> true
                    else -> p.w > p.h
                }
                val pw = if (landscape) b else a
                val ph = if (landscape) a else b
                val m = lay.margin
                val aw = max(1f, pw - 2 * m)
                val ah = max(1f, ph - 2 * m)
                val s = min(aw / p.w, ah / p.h)
                val dw = p.w * s
                val dh = p.h * s
                out.add(PdfPageSpec(p.jpeg, p.w, p.h, pw, ph, (pw - dw) / 2f, (ph - dh) / 2f, dw, dh))
            }
        }
        return out
    }

    fun writeSpecs(out: File, pages: List<PdfPageSpec>): Boolean {
        if (pages.isEmpty()) return false
        return try {
            FileOutputStream(out).use { fos ->
                val c = Counter(fos.buffered())
                val n = pages.size
                val total = 2 + 3 * n
                val offs = LongArray(total + 1)
                fun begin(num: Int) {
                    offs[num] = c.pos
                    c.w("$num 0 obj\n")
                }
                fun f2(v: Float) = String.format(Locale.US, "%.2f", v)
                c.w("%PDF-1.4\n")
                begin(1)
                c.w("<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
                begin(2)
                val kids = (0 until n).joinToString(" ") { "${3 + it * 3} 0 R" }
                c.w("<< /Type /Pages /Kids [$kids] /Count $n >>\nendobj\n")
                for (i in 0 until n) {
                    val s = pages[i]
                    val b = 3 + i * 3
                    begin(b)
                    c.w("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f2(s.pageW)} ${f2(s.pageH)}] /Resources << /XObject << /Im0 ${b + 1} 0 R >> >> /Contents ${b + 2} 0 R >>\nendobj\n")
                    begin(b + 1)
                    c.w("<< /Type /XObject /Subtype /Image /Width ${s.imgW} /Height ${s.imgH} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${s.jpeg.size} >>\nstream\n")
                    c.w(s.jpeg)
                    c.w("\nendstream\nendobj\n")
                    val content = "q ${f2(s.dw)} 0 0 ${f2(s.dh)} ${f2(s.x)} ${f2(s.y)} cm /Im0 Do Q"
                    begin(b + 2)
                    c.w("<< /Length ${content.length} >>\nstream\n$content\nendstream\nendobj\n")
                }
                val xref = c.pos
                c.w("xref\n0 ${total + 1}\n")
                c.w("0000000000 65535 f \n")
                for (k in 1..total) c.w(String.format(Locale.US, "%010d 00000 n \n", offs[k]))
                c.w("trailer\n<< /Size ${total + 1} /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n")
                c.os.flush()
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(2)

    fun load(ctx: Context, f: File, iv: ImageView, maxLong: Int) {
        load(ctx, Uri.fromFile(f), 0, iv, maxLong, f.absolutePath + "@" + f.lastModified())
    }

    fun load(ctx: Context, uri: Uri, rot: Int, iv: ImageView, maxLong: Int, keyBase: String = uri.toString()) {
        val key = "$keyBase@$rot@$maxLong"
        iv.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        val app = ctx.applicationContext
        pool.execute {
            val bmp = ImageUtil.decode(app, uri, maxLong, Int.MAX_VALUE, rot)
            if (bmp != null) {
                cache.put(key, bmp)
                iv.post { if (iv.tag == key) iv.setImageBitmap(bmp) }
            }
        }
    }
}
