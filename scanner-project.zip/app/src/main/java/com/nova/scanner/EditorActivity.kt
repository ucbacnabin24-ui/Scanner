package com.nova.scanner

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import kotlin.math.max
import kotlin.math.min

/** Finger-drawn signature pad. */
class SignaturePad(ctx: Context) : View(ctx) {
    private val path = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var any = false

    init {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 6f
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.color = Color.parseColor("#0B2A6F")
        setBackgroundColor(Color.WHITE)
    }

    override fun onDraw(c: Canvas) {
        c.drawPath(path, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent.requestDisallowInterceptTouchEvent(true)
                path.moveTo(e.x, e.y)
                any = true
            }
            MotionEvent.ACTION_MOVE -> path.lineTo(e.x, e.y)
        }
        invalidate()
        return true
    }

    fun clear() {
        path.reset()
        any = false
        invalidate()
    }

    /** Transparent bitmap cropped to the ink, or null when empty. */
    fun toBitmap(): Bitmap? {
        if (!any || width == 0) return null
        val full = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(full)
        c.drawPath(path, paint)
        val r = android.graphics.RectF()
        path.computeBounds(r, true)
        r.inset(-8f, -8f)
        val l = max(0, r.left.toInt())
        val t = max(0, r.top.toInt())
        val rr = min(width, r.right.toInt())
        val bb = min(height, r.bottom.toInt())
        if (rr - l < 4 || bb - t < 4) return null
        return Bitmap.createBitmap(full, l, t, rr - l, bb - t)
    }
}

/** Annotate a PDF: text, pen, highlight, shapes, signature, images, notes, white-out. Saves a new PDF. */
class EditorActivity : AppCompatActivity() {

    private var file: File? = null
    private var title = "document"
    private var session: PdfSession? = null
    private var pageCount = 0
    private var pageIdx = 0
    private lateinit var view: EditorView
    private lateinit var pageLabel: TextView
    private lateinit var toolLabel: TextView
    private val store = HashMap<Int, MutableList<Ann>>()
    private val history = HashMap<Int, ArrayList<List<Ann>>>()
    private val histPos = HashMap<Int, Int>()
    private var pendU = 0f
    private var pendV = 0f
    private val palette = intArrayOf(
        Color.parseColor("#E11D48"), Color.parseColor("#2563EB"), Color.parseColor("#16A34A"),
        Color.parseColor("#F59E0B"), Color.parseColor("#111827"), Color.parseColor("#7C3AED"), Color.parseColor("#FFEB3B")
    )

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val bmp = ImageUtil.decode(this, uri, 1600)
            if (bmp != null) {
                val w = view.pageW * 0.4f
                val h = w * bmp.height / bmp.width
                view.addAnn(AImage(bmp, pendU, pendV, w, h, T_IMAGE, null))
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("path")
        if (path == null) {
            finish()
            return
        }
        file = File(path)
        title = PdfCore.baseName(file!!.name)
        try {
            val s = PdfSession(file!!)
            session = s
            pageCount = s.pageCount
        } catch (e: Exception) {
            toast("Cannot open this PDF")
            finish()
            return
        }
        buildUi()
        showPage(0)
    }

    override fun onDestroy() {
        session?.close()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val (header, tv) = headerRow("Edit PDF") { finish() }
        toolLabel = tv
        header.addView(chip("\uD83D\uDC41 Preview") { preview() })
        header.addView(chip("\uD83D\uDCBE Save") { save() })
        root.addView(header)

        view = EditorView(this)
        view.onCommit = { commit() }
        view.onPlace = { tool, u, v -> place(tool, u, v) }
        view.onEditText = { a -> editText(a) }

        fun tool(label: String, t: Int): TextView = chip(label) {
            view.tool = t
            view.selected = null
            view.invalidate()
            toolLabel.text = "Tool: " + label
        }
        root.addView(chipScroll(listOf(
            tool("\u261D Select/Move", T_SELECT), tool("\u270F Pen", T_PEN), tool("\uD83D\uDD8D Marker", T_MARKER),
            tool("\u25AE Highlight", T_HIGHLIGHT), tool("U\u0332 Underline", T_UNDERLINE), tool("S\u0336 Strike", T_STRIKE),
            tool("\u25AD Rectangle", T_RECT), tool("\u25EF Ellipse", T_ELLIPSE), tool("\u2571 Line", T_LINE), tool("\u2197 Arrow", T_ARROW),
            tool("\u2B1C White-out (erase)", T_WHITEOUT), tool("T Text", T_TEXT), tool("\uD83D\uDCAC Note/Comment", T_NOTE),
            tool("\u270D Signature", T_SIGN), tool("\uD83D\uDDBC Image", T_IMAGE)
        )))
        root.addView(view, LinearLayout.LayoutParams(MATCH, 0, 1f))

        pageLabel = TextView(this)
        pageLabel.setTextColor(Color.WHITE)
        pageLabel.textSize = 13f
        pageLabel.setPadding(dp(14), dp(6), dp(14), dp(6))
        root.addView(chipScroll(listOf(
            chip("\u25C0") { if (pageIdx > 0) showPage(pageIdx - 1) },
            pageLabel,
            chip("\u25B6") { if (pageIdx < pageCount - 1) showPage(pageIdx + 1) },
            chip("\u21B6 Undo") { undo() },
            chip("\u21B7 Redo") { redo() },
            chip("\uD83D\uDDD1 Delete") { view.deleteSelected() },
            chip("\uD83C\uDFA8 Color") { colorDialog() },
            chip("\u2501 Thickness") { widthDialog() },
            chip("\uD83E\uDDE9 Pages") { organize() }
        )))
        setContentView(root)
    }

    // ---------------------------------------------------------------- pages & history
    private fun listFor(p: Int): MutableList<Ann> = store.getOrPut(p) { ArrayList() }

    private fun showPage(p: Int) {
        pageIdx = p
        val s = session ?: return
        val sz = s.pageSize(p)
        pageLabel.text = "Page ${p + 1} / $pageCount"
        view.anns = listFor(p)
        if (!history.containsKey(p)) {
            history[p] = arrayListOf(snapshot(p))
            histPos[p] = 0
        }
        Thread {
            val bmp = s.render(p, 1700)
            runOnUiThread { view.setPage(bmp, sz.first.toFloat(), sz.second.toFloat()) }
        }.start()
    }

    private fun snapshot(p: Int): List<Ann> = listFor(p).map { it.copy() }

    private fun commit() {
        val h = history.getOrPut(pageIdx) { arrayListOf(emptyList()) }
        var pos = histPos[pageIdx] ?: 0
        while (h.size > pos + 1) h.removeAt(h.size - 1)
        h.add(snapshot(pageIdx))
        if (h.size > 60) h.removeAt(0)
        pos = h.size - 1
        histPos[pageIdx] = pos
    }

    private fun restore(p: Int, idx: Int) {
        val h = history[p] ?: return
        val list = listFor(p)
        list.clear()
        h[idx].forEach { list.add(it.copy()) }
        histPos[p] = idx
        view.selected = null
        view.anns = list
        view.invalidate()
    }

    private fun undo() {
        val pos = histPos[pageIdx] ?: 0
        if (pos > 0) restore(pageIdx, pos - 1) else toast("Nothing to undo")
    }

    private fun redo() {
        val pos = histPos[pageIdx] ?: 0
        val h = history[pageIdx] ?: return
        if (pos < h.size - 1) restore(pageIdx, pos + 1) else toast("Nothing to redo")
    }

    // ---------------------------------------------------------------- tools
    private fun colorDialog() {
        val names = arrayOf("Red", "Blue", "Green", "Orange", "Black", "Purple", "Yellow")
        chooseDialog("Color", names, palette.indexOf(view.color)) {
            view.color = palette[it]
            val a = view.selected
            if (a is AShape) a.color = palette[it]
            if (a is AStroke) a.color = palette[it]
            view.invalidate()
        }
    }

    private fun widthDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(16), dp(20), dp(8))
        val lbl = TextView(this)
        lbl.text = "Thickness: ${view.strokeW.toInt()}"
        val sb = SeekBar(this)
        sb.max = 20
        sb.progress = view.strokeW.toInt()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                lbl.text = "Thickness: ${max(1, p)}"
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        box.addView(lbl)
        box.addView(sb)
        AlertDialog.Builder(this).setTitle("Line thickness").setView(box)
            .setPositiveButton("OK") { _, _ -> view.strokeW = max(1, sb.progress).toFloat() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun place(tool: Int, u: Float, v: Float) {
        pendU = u
        pendV = v
        when (tool) {
            T_TEXT -> textDialog(null, false)
            T_NOTE -> textDialog(null, true)
            T_SIGN -> signDialog()
            T_IMAGE -> imagePicker.launch("image/*")
        }
    }

    private fun textDialog(existing: AImage?, note: Boolean) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(4))
        val et = EditText(this)
        et.hint = if (note) "Comment" else "Type text (any language)"
        et.setText(existing?.spec?.text ?: "")
        et.minLines = 2
        val sizeLbl = TextView(this)
        val sb = SeekBar(this)
        sb.max = 40
        sb.progress = ((existing?.spec?.size ?: 14f) - 6f).toInt().coerceIn(0, 40)
        sizeLbl.text = "Size: ${sb.progress + 6}"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                sizeLbl.text = "Size: ${p + 6}"
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        val bold = CheckBox(this)
        bold.text = "Bold"
        bold.isChecked = existing?.spec?.bold ?: false
        box.addView(et)
        box.addView(sizeLbl)
        box.addView(sb)
        if (!note) box.addView(bold)
        AlertDialog.Builder(this)
            .setTitle(if (note) "Comment" else "Text")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val t = et.text.toString()
                if (t.isNotBlank()) {
                    val spec = TextSpec(t, (sb.progress + 6).toFloat(), view.color, bold.isChecked, note)
                    val bmp = TextRender.render(spec, view.pageW * 0.7f)
                    val w = bmp.width / TextRender.PX
                    val h = bmp.height / TextRender.PX
                    if (existing != null) {
                        view.anns.remove(existing)
                        view.addAnn(AImage(bmp, existing.x, existing.y, w, h, existing.kind, spec))
                    } else {
                        view.addAnn(AImage(bmp, pendU, pendV, w, h, if (note) T_NOTE else T_TEXT, spec))
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun editText(a: AImage) {
        textDialog(a, a.spec?.note ?: false)
    }

    private fun signFile() = File(filesDir, "signature.png")

    private fun placeSignature(bmp: Bitmap) {
        val w = view.pageW * 0.3f
        val h = w * bmp.height / bmp.width
        view.addAnn(AImage(bmp, pendU, pendV, w, h, T_SIGN, null))
    }

    private fun signDialog() {
        val f = signFile()
        if (f.exists()) {
            AlertDialog.Builder(this)
                .setTitle("Signature")
                .setItems(arrayOf("Use saved signature", "Draw a new one")) { _, i ->
                    if (i == 0) {
                        val b = android.graphics.BitmapFactory.decodeFile(f.absolutePath)
                        if (b != null) placeSignature(b) else drawSignature()
                    } else {
                        drawSignature()
                    }
                }.show()
        } else {
            drawSignature()
        }
    }

    private fun drawSignature() {
        val pad = SignaturePad(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(0))
        box.addView(pad, LinearLayout.LayoutParams(MATCH, dp(220)))
        AlertDialog.Builder(this)
            .setTitle("Sign with your finger")
            .setView(box)
            .setPositiveButton("Use") { _, _ ->
                val b = pad.toBitmap()
                if (b == null) {
                    toast("Draw your signature first")
                } else {
                    try {
                        java.io.FileOutputStream(signFile()).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    } catch (e: Exception) {
                        // not saved, still usable now
                    }
                    placeSignature(b)
                }
            }
            .setNeutralButton("Clear") { _, _ -> }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun organize() {
        file?.let { startActivity(Intent(this, OrganizerActivity::class.java).putStringArrayListExtra("paths", arrayListOf(it.absolutePath))) }
    }

    // ---------------------------------------------------------------- preview & save
    private fun annotations(): Map<Int, List<Ann>> = store.filter { it.value.isNotEmpty() }

    private fun preview() {
        val src = file ?: return
        val anns = annotations()
        if (anns.isEmpty()) {
            toast("Nothing changed yet")
            return
        }
        runBusy("Building preview\u2026", { p ->
            val out = PdfCore.newWorkFile(this, "preview")
            if (PdfAnnotWriter.apply(src, out, anns, p)) out else null
        }, { f ->
            if (f == null) toast("Could not build the preview")
            else startActivity(Intent(this, ReaderActivity::class.java).putExtra("path", f.absolutePath).putExtra("title", "Preview"))
        })
    }

    private fun save() {
        val src = file ?: return
        val anns = annotations()
        if (anns.isEmpty()) {
            toast("Nothing changed yet")
            return
        }
        runBusy("Saving\u2026", { p ->
            val out = PdfCore.newWorkFile(this, "edit")
            if (PdfAnnotWriter.apply(src, out, anns, p)) ScanStore.addPdf(this, out, "Edited - $title") else null
        }, { s ->
            if (s == null) {
                toast("Could not save the PDF")
            } else {
                toast("Saved to My Documents")
                startActivity(Intent(this, ReaderActivity::class.java).putExtra("path", s.pdf?.absolutePath).putExtra("title", s.name))
                finish()
            }
        })
    }
}
