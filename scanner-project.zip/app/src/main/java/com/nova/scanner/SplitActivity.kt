package com.nova.scanner

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File

/** Split a PDF: every page, every N pages, or custom ranges like 1-3,5,8-10. Results go to a new folder. */
class SplitActivity : AppCompatActivity() {

    private var src: File? = null
    private var srcName = "document"
    private var total = 0
    private var mode = 0
    private lateinit var fileInfo: TextView
    private lateinit var input: EditText
    private lateinit var modeChip: TextView

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runBusy("Reading PDF\u2026", { _ ->
                val f = PdfCore.cacheCopy(this, uri)
                var n = 0
                if (f != null) {
                    val s = PdfSession(f)
                    n = s.pageCount
                    s.close()
                }
                if (f != null) Pair(f, n) else null
            }, { r ->
                if (r == null) {
                    toast("Could not read this PDF")
                } else {
                    src = r.first
                    total = r.second
                    srcName = PdfCore.baseName(PdfCore.displayName(this, uri))
                    fileInfo.text = "$srcName  \u2022  $total pages"
                }
            })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val (header, _) = headerRow("Split PDF") { finish() }
        root.addView(header)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(8), dp(16), dp(8))
        body.addView(bigButton("\uD83D\uDCC4 Choose PDF", BLUE) { picker.launch(arrayOf("application/pdf")) })
        fileInfo = TextView(this)
        fileInfo.setTextColor(Color.WHITE)
        fileInfo.setPadding(0, dp(10), 0, dp(10))
        fileInfo.text = "No file chosen"
        body.addView(fileInfo)
        modeChip = chip("") {
            chooseDialog("Split method", arrayOf("Every page (one PDF per page)", "Every N pages", "Custom ranges (1-3,5,8-10)"), mode) {
                mode = it
                refreshMode()
            }
        }
        body.addView(modeChip)
        input = EditText(this)
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(GRAY)
        input.maxLines = 1
        body.addView(input)
        val tip = TextView(this)
        tip.setTextColor(GRAY)
        tip.textSize = 12f
        tip.text = "Custom ranges: each comma-separated part becomes its own PDF.\nTo pick pages from different PDFs, use Merge PDF."
        tip.setPadding(0, dp(8), 0, dp(12))
        body.addView(tip)
        body.addView(bigButton("\u2702 Split", GREEN) { split() })
        root.addView(body)
        setContentView(root)
        refreshMode()
    }

    private fun refreshMode() {
        modeChip.text = "Method: " + arrayOf("Every page", "Every N pages", "Custom ranges")[mode]
        when (mode) {
            0 -> {
                input.visibility = android.view.View.GONE
            }
            1 -> {
                input.visibility = android.view.View.VISIBLE
                input.hint = "N (pages per file), e.g. 5"
                input.inputType = InputType.TYPE_CLASS_NUMBER
            }
            else -> {
                input.visibility = android.view.View.VISIBLE
                input.hint = "e.g. 1-3,5,8-10"
                input.inputType = InputType.TYPE_CLASS_TEXT
            }
        }
    }

    private fun parts(): List<List<Int>>? {
        val groups = ArrayList<List<Int>>()
        when (mode) {
            0 -> for (i in 0 until total) groups.add(listOf(i))
            1 -> {
                val n = input.text.toString().trim().toIntOrNull()
                if (n == null || n < 1) return null
                var i = 0
                while (i < total) {
                    groups.add((i until minOf(total, i + n)).toList())
                    i += n
                }
            }
            else -> {
                for (part in input.text.toString().split(",")) {
                    val t = part.trim()
                    if (t.isEmpty()) continue
                    val ab = t.split("-")
                    val a = ab[0].trim().toIntOrNull() ?: return null
                    val b = if (ab.size > 1) (ab[1].trim().toIntOrNull() ?: return null) else a
                    if (a < 1 || b > total || a > b) return null
                    groups.add((a - 1 until b).toList())
                }
            }
        }
        return if (groups.isEmpty()) null else groups
    }

    private fun split() {
        val f = src
        if (f == null) {
            toast("Choose a PDF first")
            return
        }
        val groups = parts()
        if (groups == null) {
            toast("Check the page numbers")
            return
        }
        val folder = "Split - $srcName"
        Folders.add(this, folder)
        runBusy("Splitting\u2026", { p ->
            var made = 0
            val source = PdfCore.load(f)
            try {
                groups.forEachIndexed { gi, pages ->
                    p("Creating file ${gi + 1} / ${groups.size}\u2026")
                    val dest = PDDocument(MemoryUsageSetting.setupTempFileOnly())
                    try {
                        for (pi in pages) dest.importPage(source.getPage(pi))
                        val out = PdfCore.newWorkFile(this, "split")
                        dest.save(out)
                        val label = if (pages.size == 1) "p${pages[0] + 1}" else "p${pages.first() + 1}-${pages.last() + 1}"
                        if (ScanStore.addPdf(this, out, "$srcName ($label)", folder) != null) made++
                        out.delete()
                    } finally {
                        dest.close()
                    }
                }
            } finally {
                source.close()
            }
            made
        }, { n ->
            if (n == null || n == 0) {
                toast("Could not split this PDF")
            } else {
                toast("$n PDF(s) saved in folder \"$folder\"")
                startActivity(Intent(this, LibraryActivity::class.java))
                finish()
            }
        })
    }
}
