package com.nova.scanner

import android.content.Intent
import android.net.Uri
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

object Actions {

    fun uriFor(a: AppCompatActivity, f: File): Uri =
        FileProvider.getUriForFile(a, a.packageName + ".fileprovider", f)

    fun shareDialog(a: AppCompatActivity, s: Scan) {
        AlertDialog.Builder(a)
            .setTitle("Share as")
            .setItems(arrayOf("PDF  (best for WhatsApp / Email)", "Images (JPG)")) { _, i ->
                if (i == 0) sharePdf(a, s) else shareImages(a, s)
            }
            .show()
    }

    fun sharePdf(a: AppCompatActivity, s: Scan) {
        val pdf = s.pdf
        if (pdf == null) {
            a.toast("No PDF found")
            return
        }
        val i = Intent(Intent.ACTION_SEND)
        i.type = "application/pdf"
        i.putExtra(Intent.EXTRA_STREAM, uriFor(a, pdf))
        i.putExtra(Intent.EXTRA_SUBJECT, s.name)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        a.startActivity(Intent.createChooser(i, "Share PDF"))
    }

    fun shareImages(a: AppCompatActivity, s: Scan) {
        if (s.pages.isEmpty()) {
            a.toast("No images found")
            return
        }
        val uris = ArrayList<Uri>(s.pages.map { uriFor(a, it) })
        val i: Intent
        if (uris.size == 1) {
            i = Intent(Intent.ACTION_SEND)
            i.putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            i = Intent(Intent.ACTION_SEND_MULTIPLE)
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        i.type = "image/jpeg"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        a.startActivity(Intent.createChooser(i, "Share images"))
    }

    fun rename(a: AppCompatActivity, s: Scan, onDone: () -> Unit) {
        val et = EditText(a)
        et.setText(s.name)
        et.setSelection(et.text.length)
        et.setPadding(a.dp(20), a.dp(16), a.dp(20), a.dp(8))
        AlertDialog.Builder(a)
            .setTitle("Rename")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    ScanStore.rename(s, n)
                    onDone()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun delete(a: AppCompatActivity, s: Scan, onDone: () -> Unit) {
        AlertDialog.Builder(a)
            .setTitle("Delete this scan?")
            .setMessage(s.name)
            .setPositiveButton("Delete") { _, _ ->
                ScanStore.delete(s)
                onDone()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
