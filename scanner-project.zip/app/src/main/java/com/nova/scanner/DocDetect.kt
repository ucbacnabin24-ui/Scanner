package com.nova.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Document edge detection and perspective correction (OpenCV). */
object DocDetect {
    @Volatile
    private var state: Boolean? = null

    fun ready(): Boolean {
        val cur = state
        if (cur != null) return cur
        val r: Boolean = try {
            OpenCVLoader.initLocal()
        } catch (e: Throwable) {
            false
        }
        state = r
        return r
    }

    private fun order(p: Array<Point>, w: Double, h: Double): Array<PointF> {
        val tl = p.minByOrNull { it.x + it.y }!!
        val br = p.maxByOrNull { it.x + it.y }!!
        val tr = p.minByOrNull { it.y - it.x }!!
        val bl = p.maxByOrNull { it.y - it.x }!!
        fun n(pt: Point) = PointF((pt.x / w).toFloat().coerceIn(0f, 1f), (pt.y / h).toFloat().coerceIn(0f, 1f))
        return arrayOf(n(tl), n(tr), n(br), n(bl))
    }

    /** gray: single-channel image. Returns normalized corners tl, tr, br, bl or null. */
    fun findQuad(gray: Mat): Array<PointF>? {
        if (!ready()) return null
        val small = Mat()
        val blur = Mat()
        val edges = Mat()
        val hier = Mat()
        try {
            val scale = 500.0 / max(gray.cols(), gray.rows())
            Imgproc.resize(gray, small, Size(), scale, scale, Imgproc.INTER_AREA)
            Imgproc.GaussianBlur(small, blur, Size(5.0, 5.0), 0.0)
            Imgproc.Canny(blur, edges, 60.0, 180.0)
            val k = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0))
            Imgproc.dilate(edges, edges, k)
            k.release()
            val contours = ArrayList<MatOfPoint>()
            Imgproc.findContours(edges, contours, hier, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE)
            contours.sortByDescending { Imgproc.contourArea(it) }
            val minArea = small.rows() * small.cols() * 0.18
            var best: Array<PointF>? = null
            for (c in contours.take(8)) {
                if (Imgproc.contourArea(c) < minArea) break
                val c2f = MatOfPoint2f(*c.toArray())
                val peri = Imgproc.arcLength(c2f, true)
                val approx = MatOfPoint2f()
                Imgproc.approxPolyDP(c2f, approx, 0.02 * peri, true)
                val pts = approx.toArray()
                val isQuad = pts.size == 4 && Imgproc.isContourConvex(MatOfPoint(*pts))
                c2f.release()
                approx.release()
                if (isQuad) {
                    best = order(pts, small.cols().toDouble(), small.rows().toDouble())
                    break
                }
            }
            contours.forEach { it.release() }
            return best
        } finally {
            small.release()
            blur.release()
            edges.release()
            hier.release()
        }
    }

    fun findQuadBitmap(bmp: Bitmap): Array<PointF>? {
        if (!ready()) return null
        val rgba = Mat()
        val gray = Mat()
        try {
            Utils.bitmapToMat(bmp, rgba)
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            return findQuad(gray)
        } finally {
            rgba.release()
            gray.release()
        }
    }

    private fun dist(a: Point, b: Point) = hypot(a.x - b.x, a.y - b.y)

    /** Straightens the page inside [q] (normalized tl, tr, br, bl). Falls back to a plain crop without OpenCV. */
    fun warp(bmp: Bitmap, q: Array<PointF>): Bitmap {
        val w = bmp.width.toDouble()
        val h = bmp.height.toDouble()
        val pts = q.map { Point(it.x * w, it.y * h) }
        if (ready()) {
            val wTop = dist(pts[0], pts[1])
            val wBot = dist(pts[3], pts[2])
            val hL = dist(pts[0], pts[3])
            val hR = dist(pts[1], pts[2])
            var dw = max(wTop, wBot)
            var dh = max(hL, hR)
            val big = max(dw, dh)
            if (big > 4200) {
                dw = dw * 4200 / big
                dh = dh * 4200 / big
            }
            val iw = dw.roundToInt().coerceAtLeast(50)
            val ih = dh.roundToInt().coerceAtLeast(50)
            val src = MatOfPoint2f(*pts.toTypedArray())
            val dst = MatOfPoint2f(Point(0.0, 0.0), Point(iw - 1.0, 0.0), Point(iw - 1.0, ih - 1.0), Point(0.0, ih - 1.0))
            val inMat = Mat()
            val outMat = Mat()
            val m = Imgproc.getPerspectiveTransform(src, dst)
            try {
                Utils.bitmapToMat(bmp, inMat)
                Imgproc.warpPerspective(inMat, outMat, m, Size(iw.toDouble(), ih.toDouble()), Imgproc.INTER_CUBIC)
                val res = Bitmap.createBitmap(iw, ih, Bitmap.Config.ARGB_8888)
                Utils.matToBitmap(outMat, res)
                return res
            } finally {
                src.release()
                dst.release()
                inMat.release()
                outMat.release()
                m.release()
            }
        }
        val l = pts.minOf { it.x }.toInt().coerceIn(0, bmp.width - 2)
        val t = pts.minOf { it.y }.toInt().coerceIn(0, bmp.height - 2)
        val r = pts.maxOf { it.x }.toInt().coerceIn(l + 1, bmp.width)
        val b = pts.maxOf { it.y }.toInt().coerceIn(t + 1, bmp.height)
        return Bitmap.createBitmap(bmp, l, t, r - l, b - t)
    }
}

/** Shows the page and 4 draggable corner handles. */
class CropView(ctx: Context) : View(ctx) {
    private var bmp: Bitmap? = null
    private var quad = defaultQuad()
    private var drag = -1
    private val dst = RectF()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        line.style = Paint.Style.STROKE
        line.strokeWidth = 4f
        line.color = Color.parseColor("#22C55E")
        fill.color = Color.argb(40, 34, 197, 94)
        handle.color = Color.parseColor("#22C55E")
    }

    private fun defaultQuad() = arrayOf(PointF(0.04f, 0.04f), PointF(0.96f, 0.04f), PointF(0.96f, 0.96f), PointF(0.04f, 0.96f))

    fun setImage(b: Bitmap, q: Array<PointF>?) {
        bmp = b
        quad = if (q != null) Array(4) { PointF(q[it].x, q[it].y) } else defaultQuad()
        layoutRect()
        invalidate()
    }

    fun getQuad(): Array<PointF> = Array(4) { PointF(quad[it].x, quad[it].y) }

    private fun layoutRect() {
        val b = bmp ?: return
        if (width == 0) return
        val s = min(width.toFloat() / b.width, height.toFloat() / b.height)
        val w = b.width * s
        val h = b.height * s
        dst.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        layoutRect()
    }

    private fun sx(p: PointF) = dst.left + p.x * dst.width()
    private fun sy(p: PointF) = dst.top + p.y * dst.height()

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.parseColor("#111111"))
        val b = bmp ?: return
        c.drawBitmap(b, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
        val path = Path()
        path.moveTo(sx(quad[0]), sy(quad[0]))
        for (i in 1..3) path.lineTo(sx(quad[i]), sy(quad[i]))
        path.close()
        c.drawPath(path, fill)
        c.drawPath(path, line)
        for (p in quad) c.drawCircle(sx(p), sy(p), 18f, handle)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                var best = -1
                var bd = 90f
                for (i in 0..3) {
                    val d = hypot(sx(quad[i]) - e.x, sy(quad[i]) - e.y)
                    if (d < bd) {
                        bd = d
                        best = i
                    }
                }
                drag = best
                return true
            }
            MotionEvent.ACTION_MOVE -> if (drag >= 0 && dst.width() > 0) {
                quad[drag].x = ((e.x - dst.left) / dst.width()).coerceIn(0f, 1f)
                quad[drag].y = ((e.y - dst.top) / dst.height()).coerceIn(0f, 1f)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> drag = -1
        }
        return true
    }
}

/** Live outline drawn over the camera preview. */
class QuadOverlay(ctx: Context) : View(ctx) {
    var quad: Array<PointF>? = null
    var aspect = 0.75f
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        line.style = Paint.Style.STROKE
        line.strokeWidth = 5f
        line.color = Color.parseColor("#22C55E")
        fill.color = Color.argb(45, 34, 197, 94)
    }

    override fun onDraw(c: Canvas) {
        val q = quad ?: return
        val vw = width.toFloat()
        val vh = height.toFloat()
        var cw = vw
        var ch = vw / aspect
        if (ch > vh) {
            ch = vh
            cw = vh * aspect
        }
        val ox = (vw - cw) / 2f
        val oy = (vh - ch) / 2f
        val path = Path()
        path.moveTo(ox + q[0].x * cw, oy + q[0].y * ch)
        for (i in 1..3) path.lineTo(ox + q[i].x * cw, oy + q[i].y * ch)
        path.close()
        c.drawPath(path, fill)
        c.drawPath(path, line)
    }
}
