package com.nova.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.util.Matrix
import java.io.File
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

const val T_SELECT = 0
const val T_PEN = 1
const val T_MARKER = 2
const val T_HIGHLIGHT = 3
const val T_UNDERLINE = 4
const val T_STRIKE = 5
const val T_RECT = 6
const val T_ELLIPSE = 7
const val T_LINE = 8
const val T_ARROW = 9
const val T_WHITEOUT = 10
const val T_TEXT = 11
const val T_NOTE = 12
const val T_SIGN = 13
const val T_IMAGE = 14

/** Annotations live in "display points": u right, v down, origin top-left of the displayed page. */
abstract class Ann {
    abstract fun draw(c: Canvas, s: Float)
    abstract fun bounds(): RectF
    abstract fun hit(u: Float, v: Float, tol: Float): Boolean
    abstract fun move(du: Float, dv: Float)
    abstract fun copy(): Ann
    open fun resizeBy(du: Float, dv: Float) {}
}

class AStroke(val pts: ArrayList<PointF>, var color: Int, var width: Float, var alpha: Int) : Ann() {
    override fun draw(c: Canvas, s: Float) {
        if (pts.isEmpty()) return
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = color
        p.alpha = alpha
        p.strokeWidth = width * s
        val path = Path()
        path.moveTo(pts[0].x * s, pts[0].y * s)
        if (pts.size == 1) path.lineTo(pts[0].x * s + 0.1f, pts[0].y * s)
        for (i in 1 until pts.size) path.lineTo(pts[i].x * s, pts[i].y * s)
        c.drawPath(path, p)
    }

    override fun bounds(): RectF {
        val r = RectF(pts[0].x, pts[0].y, pts[0].x, pts[0].y)
        for (p in pts) r.union(p.x, p.y)
        r.inset(-width / 2f, -width / 2f)
        return r
    }

    override fun hit(u: Float, v: Float, tol: Float): Boolean {
        for (i in 0 until pts.size - 1) if (distToSeg(u, v, pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y) <= tol + width / 2f) return true
        return pts.size == 1 && hypot(pts[0].x - u, pts[0].y - v) <= tol + width / 2f
    }

    override fun move(du: Float, dv: Float) {
        for (p in pts) p.offset(du, dv)
    }

    override fun copy(): Ann = AStroke(ArrayList(pts.map { PointF(it.x, it.y) }), color, width, alpha)
}

class AShape(
    val kind: Int, var x0: Float, var y0: Float, var x1: Float, var y1: Float,
    var color: Int, var width: Float
) : Ann() {
    private fun rect() = RectF(min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1))

    override fun draw(c: Canvas, s: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.strokeWidth = width * s
        p.strokeCap = Paint.Cap.ROUND
        val r = rect()
        val rs = RectF(r.left * s, r.top * s, r.right * s, r.bottom * s)
        when (kind) {
            T_HIGHLIGHT -> {
                p.style = Paint.Style.FILL
                p.alpha = 90
                c.drawRect(rs, p)
            }
            T_WHITEOUT -> {
                p.style = Paint.Style.FILL
                p.color = Color.WHITE
                c.drawRect(rs, p)
            }
            T_UNDERLINE -> {
                p.style = Paint.Style.STROKE
                c.drawLine(rs.left, rs.bottom, rs.right, rs.bottom, p)
            }
            T_STRIKE -> {
                p.style = Paint.Style.STROKE
                val my = (rs.top + rs.bottom) / 2f
                c.drawLine(rs.left, my, rs.right, my, p)
            }
            T_RECT -> {
                p.style = Paint.Style.STROKE
                c.drawRect(rs, p)
            }
            T_ELLIPSE -> {
                p.style = Paint.Style.STROKE
                c.drawOval(rs, p)
            }
            T_LINE, T_ARROW -> {
                p.style = Paint.Style.STROKE
                c.drawLine(x0 * s, y0 * s, x1 * s, y1 * s, p)
                if (kind == T_ARROW) {
                    for (pt in arrowHead()) c.drawLine(x1 * s, y1 * s, pt.x * s, pt.y * s, p)
                }
            }
        }
    }

    fun arrowHead(): List<PointF> {
        val ang = atan2((y1 - y0).toDouble(), (x1 - x0).toDouble())
        val len = max(10f, width * 4f)
        val a1 = ang + Math.PI * 0.85
        val a2 = ang - Math.PI * 0.85
        return listOf(
            PointF(x1 + (len * cos(a1)).toFloat(), y1 + (len * sin(a1)).toFloat()),
            PointF(x1 + (len * cos(a2)).toFloat(), y1 + (len * sin(a2)).toFloat())
        )
    }

    override fun bounds(): RectF {
        val r = rect()
        r.inset(-width, -width)
        return r
    }

    override fun hit(u: Float, v: Float, tol: Float): Boolean {
        if (kind == T_LINE || kind == T_ARROW) return distToSeg(u, v, x0, y0, x1, y1) <= tol + width
        val r = rect()
        r.inset(-tol, -tol)
        return r.contains(u, v)
    }

    override fun move(du: Float, dv: Float) {
        x0 += du
        x1 += du
        y0 += dv
        y1 += dv
    }

    override fun resizeBy(du: Float, dv: Float) {
        x1 += du
        y1 += dv
    }

    override fun copy(): Ann = AShape(kind, x0, y0, x1, y1, color, width)
}

class TextSpec(val text: String, val size: Float, val color: Int, val bold: Boolean, val note: Boolean)

object TextRender {
    const val PX = 3f

    fun render(spec: TextSpec, maxWidthPt: Float): Bitmap {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = spec.size * PX
        paint.color = if (spec.note) Color.parseColor("#333333") else spec.color
        if (spec.bold) paint.isFakeBoldText = true
        val pad = if (spec.note) 6f * PX else 2f * PX
        val w = max(40, (maxWidthPt * PX - 2 * pad).toInt())
        val layout = StaticLayout.Builder.obtain(spec.text, 0, spec.text.length, paint, w)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.05f)
            .build()
        var textW = 0f
        for (i in 0 until layout.lineCount) textW = max(textW, layout.getLineWidth(i))
        val bw = (textW + 2 * pad).toInt().coerceAtLeast(8)
        val bh = (layout.height + 2 * pad).toInt().coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (spec.note) {
            val bg = Paint(Paint.ANTI_ALIAS_FLAG)
            bg.color = Color.parseColor("#FFF59D")
            c.drawRoundRect(RectF(0f, 0f, bw.toFloat(), bh.toFloat()), 8f, 8f, bg)
        }
        c.translate(pad, pad)
        layout.draw(c)
        return bmp
    }
}

class AImage(
    var bmp: Bitmap, var x: Float, var y: Float, var w: Float, var h: Float,
    val kind: Int, val spec: TextSpec?
) : Ann() {
    override fun draw(c: Canvas, s: Float) {
        c.drawBitmap(bmp, null, RectF(x * s, y * s, (x + w) * s, (y + h) * s), Paint(Paint.FILTER_BITMAP_FLAG))
    }

    override fun bounds(): RectF = RectF(x, y, x + w, y + h)
    override fun hit(u: Float, v: Float, tol: Float): Boolean {
        val r = bounds()
        r.inset(-tol, -tol)
        return r.contains(u, v)
    }

    override fun move(du: Float, dv: Float) {
        x += du
        y += dv
    }

    override fun resizeBy(du: Float, dv: Float) {
        val nw = max(12f, w + du)
        h = h * nw / w
        w = nw
    }

    override fun copy(): Ann = AImage(bmp, x, y, w, h, kind, spec)
}

fun distToSeg(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
    val dx = bx - ax
    val dy = by - ay
    val l2 = dx * dx + dy * dy
    if (l2 == 0f) return hypot(px - ax, py - ay)
    val t = (((px - ax) * dx + (py - ay) * dy) / l2).coerceIn(0f, 1f)
    return hypot(px - (ax + t * dx), py - (ay + t * dy))
}

/** The page + annotation canvas with pinch-zoom, pan, drawing tools, selection, move and resize. */
class EditorView(ctx: Context) : View(ctx) {
    var page: Bitmap? = null
    var pageW = 1f
    var pageH = 1f
    var anns: MutableList<Ann> = ArrayList()
    var tool = T_SELECT
    var color = Color.RED
    var strokeW = 3f
    var onCommit: (() -> Unit)? = null
    var onPlace: ((Int, Float, Float) -> Unit)? = null
    var onEditText: ((AImage) -> Unit)? = null
    var selected: Ann? = null

    private var zoom = 1f
    private var tx = 0f
    private var ty = 0f
    private var current: Ann? = null
    private var multi = false
    private var lastMidX = 0f
    private var lastMidY = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var dragging = false
    private var resizing = false
    private var changed = false
    private val handleR = 22f

    private val scale = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val nz = (zoom * d.scaleFactor).coerceIn(1f, 6f)
            val r = nz / zoom
            tx = d.focusX - (d.focusX - tx) * r
            ty = d.focusY - (d.focusY - ty) * r
            zoom = nz
            clamp()
            invalidate()
            return true
        }
    })
    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (tool == T_SELECT) {
                val a = hitTest(toU(e.x), toV(e.y))
                if (a is AImage && a.spec != null) {
                    onEditText?.invoke(a)
                    return true
                }
            }
            return false
        }
    })

    private fun s0(): Float = min(width / pageW, height / pageH)
    private fun s(): Float = s0() * zoom
    private fun toU(x: Float) = (x - tx) / s()
    private fun toV(y: Float) = (y - ty) / s()

    fun setPage(b: Bitmap?, w: Float, h: Float) {
        page = b
        pageW = w
        pageH = h
        zoom = 1f
        selected = null
        fit()
        invalidate()
    }

    private fun fit() {
        if (width == 0) return
        tx = (width - pageW * s()) / 2f
        ty = (height - pageH * s()) / 2f
    }

    private fun clamp() {
        val pw = pageW * s()
        val ph = pageH * s()
        tx = if (pw <= width) (width - pw) / 2f else tx.coerceIn(width - pw, 0f)
        ty = if (ph <= height) (height - ph) / 2f else ty.coerceIn(height - ph, 0f)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fit()
    }

    fun hitTest(u: Float, v: Float): Ann? {
        val tol = 12f / s()
        for (i in anns.indices.reversed()) if (anns[i].hit(u, v, tol)) return anns[i]
        return null
    }

    fun addAnn(a: Ann) {
        anns.add(a)
        selected = a
        onCommit?.invoke()
        invalidate()
    }

    fun deleteSelected() {
        val a = selected ?: return
        anns.remove(a)
        selected = null
        onCommit?.invoke()
        invalidate()
    }

    fun visiblePageCenter(): PointF = PointF(toU(width / 2f), toV(height / 2f))

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.parseColor("#3A3A3A"))
        val sc = s()
        c.save()
        c.translate(tx, ty)
        val pr = RectF(0f, 0f, pageW * sc, pageH * sc)
        val b = page
        if (b != null) c.drawBitmap(b, null, pr, Paint(Paint.FILTER_BITMAP_FLAG))
        else {
            val p = Paint()
            p.color = Color.WHITE
            c.drawRect(pr, p)
        }
        for (a in anns) a.draw(c, sc)
        current?.draw(c, sc)
        val sel = selected
        if (sel != null) {
            val r = sel.bounds()
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.style = Paint.Style.STROKE
            p.color = Color.parseColor("#2563EB")
            p.strokeWidth = 2f
            p.pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
            c.drawRect(r.left * sc, r.top * sc, r.right * sc, r.bottom * sc, p)
            if (sel !is AStroke) {
                val hp = Paint(Paint.ANTI_ALIAS_FLAG)
                hp.color = Color.parseColor("#2563EB")
                c.drawCircle(r.right * sc, r.bottom * sc, handleR * 0.6f, hp)
            }
        }
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scale.onTouchEvent(e)
        gd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multi = false
                downX = e.x
                downY = e.y
                moved = false
                down(e.x, e.y)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                multi = true
                current = null
                dragging = false
                resizing = false
                lastMidX = (e.getX(0) + e.getX(1)) / 2f
                lastMidY = (e.getY(0) + e.getY(1)) / 2f
            }
            MotionEvent.ACTION_MOVE -> {
                if (multi) {
                    if (e.pointerCount >= 2) {
                        val mx = (e.getX(0) + e.getX(1)) / 2f
                        val my = (e.getY(0) + e.getY(1)) / 2f
                        tx += mx - lastMidX
                        ty += my - lastMidY
                        lastMidX = mx
                        lastMidY = my
                        clamp()
                        invalidate()
                    }
                } else {
                    if (abs(e.x - downX) > 8f || abs(e.y - downY) > 8f) moved = true
                    move(e.x, e.y)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!multi) up(e.x, e.y, e.actionMasked == MotionEvent.ACTION_UP)
                multi = false
            }
        }
        return true
    }

    private var lastU = 0f
    private var lastV = 0f
    private var panning = false

    private fun down(x: Float, y: Float) {
        val u = toU(x)
        val v = toV(y)
        lastU = u
        lastV = v
        dragging = false
        resizing = false
        panning = false
        changed = false
        when (tool) {
            T_SELECT -> {
                val sel = selected
                if (sel != null && sel !is AStroke) {
                    val r = sel.bounds()
                    if (hypot(r.right - u, r.bottom - v) < handleR / s() * 1.3f) {
                        resizing = true
                        return
                    }
                }
                val a = hitTest(u, v)
                if (a != null) {
                    selected = a
                    dragging = true
                } else {
                    selected = null
                    panning = true
                    lastMidX = x
                    lastMidY = y
                }
                invalidate()
            }
            T_PEN -> current = AStroke(arrayListOf(PointF(u, v)), color, strokeW, 255)
            T_MARKER -> current = AStroke(arrayListOf(PointF(u, v)), color, max(12f, strokeW * 4f), 90)
            T_TEXT, T_NOTE, T_SIGN, T_IMAGE -> {}
            else -> current = AShape(tool, u, v, u, v, color, strokeW)
        }
        invalidate()
    }

    private fun move(x: Float, y: Float) {
        val u = toU(x)
        val v = toV(y)
        when {
            resizing -> {
                selected?.resizeBy(u - lastU, v - lastV)
                changed = true
            }
            dragging -> {
                selected?.move(u - lastU, v - lastV)
                changed = true
            }
            panning -> {
                tx += x - lastMidX
                ty += y - lastMidY
                lastMidX = x
                lastMidY = y
                clamp()
            }
            current is AStroke -> (current as AStroke).pts.add(PointF(u, v))
            current is AShape -> {
                (current as AShape).x1 = u
                (current as AShape).y1 = v
            }
        }
        lastU = u
        lastV = v
        invalidate()
    }

    private fun up(x: Float, y: Float, isUp: Boolean) {
        val cur = current
        current = null
        if (isUp) {
            when {
                cur != null -> {
                    var ok = true
                    if (cur is AShape && cur.kind != T_LINE && cur.kind != T_ARROW) {
                        ok = abs(cur.x1 - cur.x0) > 3f && abs(cur.y1 - cur.y0) > 3f
                        if (cur.kind == T_UNDERLINE || cur.kind == T_STRIKE) ok = abs(cur.x1 - cur.x0) > 3f
                    }
                    if (cur is AShape && (cur.kind == T_LINE || cur.kind == T_ARROW)) ok = hypot(cur.x1 - cur.x0, cur.y1 - cur.y0) > 4f
                    if (ok) {
                        anns.add(cur)
                        onCommit?.invoke()
                    }
                }
                (dragging || resizing) && changed -> onCommit?.invoke()
                !moved && (tool == T_TEXT || tool == T_NOTE || tool == T_SIGN || tool == T_IMAGE) ->
                    onPlace?.invoke(tool, toU(x), toV(y))
            }
        }
        dragging = false
        resizing = false
        panning = false
        invalidate()
    }
}

/** Writes the annotations into the PDF with PDFBox (flattened, works in every PDF viewer). */
object PdfAnnotWriter {
    private class Geo(val x0: Float, val y0: Float, val w: Float, val h: Float, val rot: Int) {
        fun mx(u: Float, v: Float): Float = when (rot) {
            90 -> x0 + v
            180 -> x0 + w - u
            270 -> x0 + w - v
            else -> x0 + u
        }

        fun my(u: Float, v: Float): Float = when (rot) {
            90 -> y0 + u
            180 -> y0 + v
            270 -> y0 + h - u
            else -> y0 + h - v
        }
    }

    private fun dirU(rot: Int): Pair<Float, Float> = when (rot) {
        90 -> Pair(0f, 1f)
        180 -> Pair(-1f, 0f)
        270 -> Pair(0f, -1f)
        else -> Pair(1f, 0f)
    }

    private fun dirV(rot: Int): Pair<Float, Float> = when (rot) {
        90 -> Pair(1f, 0f)
        180 -> Pair(0f, 1f)
        270 -> Pair(-1f, 0f)
        else -> Pair(0f, -1f)
    }

    fun apply(src: File, out: File, byPage: Map<Int, List<Ann>>, progress: (String) -> Unit): Boolean {
        val doc = PdfCore.load(src)
        return try {
            for ((idx, list) in byPage) {
                if (list.isEmpty()) continue
                progress("Writing page ${idx + 1}\u2026")
                val page = doc.getPage(idx)
                val box = page.cropBox
                val rot = ((page.rotation % 360) + 360) % 360
                val geo = Geo(box.lowerLeftX, box.lowerLeftY, box.width, box.height, rot)
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    for (a in list) drawAnn(doc, cs, a, geo)
                }
            }
            doc.save(out)
            true
        } catch (e: Exception) {
            false
        } finally {
            doc.close()
        }
    }

    private fun rgb(cs: PDPageContentStream, color: Int, stroking: Boolean) {
        val r = Color.red(color) / 255f
        val g = Color.green(color) / 255f
        val b = Color.blue(color) / 255f
        if (stroking) cs.setStrokingColor(r, g, b) else cs.setNonStrokingColor(r, g, b)
    }

    private fun alpha(cs: PDPageContentStream, a: Float) {
        val gs = PDExtendedGraphicsState()
        gs.setStrokingAlphaConstant(a)
        gs.setNonStrokingAlphaConstant(a)
        cs.setGraphicsStateParameters(gs)
    }

    private fun drawAnn(doc: PDDocument, cs: PDPageContentStream, a: Ann, g: Geo) {
        when (a) {
            is AStroke -> {
                if (a.pts.isEmpty()) return
                cs.saveGraphicsState()
                if (a.alpha < 255) alpha(cs, a.alpha / 255f)
                rgb(cs, a.color, true)
                cs.setLineWidth(a.width)
                cs.setLineCapStyle(1)
                cs.setLineJoinStyle(1)
                cs.moveTo(g.mx(a.pts[0].x, a.pts[0].y), g.my(a.pts[0].x, a.pts[0].y))
                if (a.pts.size == 1) cs.lineTo(g.mx(a.pts[0].x + 0.1f, a.pts[0].y), g.my(a.pts[0].x + 0.1f, a.pts[0].y))
                for (i in 1 until a.pts.size) cs.lineTo(g.mx(a.pts[i].x, a.pts[i].y), g.my(a.pts[i].x, a.pts[i].y))
                cs.stroke()
                cs.restoreGraphicsState()
            }
            is AShape -> drawShape(cs, a, g)
            is AImage -> drawImage(doc, cs, a, g)
            else -> {}
        }
    }

    private fun drawShape(cs: PDPageContentStream, a: AShape, g: Geo) {
        val u0 = min(a.x0, a.x1)
        val u1 = max(a.x0, a.x1)
        val v0 = min(a.y0, a.y1)
        val v1 = max(a.y0, a.y1)
        val xa = g.mx(u0, v0)
        val xb = g.mx(u1, v1)
        val ya = g.my(u0, v0)
        val yb = g.my(u1, v1)
        val rx = min(xa, xb)
        val ry = min(ya, yb)
        val rw = abs(xb - xa)
        val rh = abs(yb - ya)
        cs.saveGraphicsState()
        when (a.kind) {
            T_HIGHLIGHT -> {
                alpha(cs, 0.35f)
                rgb(cs, a.color, false)
                cs.addRect(rx, ry, rw, rh)
                cs.fill()
            }
            T_WHITEOUT -> {
                rgb(cs, Color.WHITE, false)
                cs.addRect(rx, ry, rw, rh)
                cs.fill()
            }
            T_RECT -> {
                rgb(cs, a.color, true)
                cs.setLineWidth(a.width)
                cs.addRect(rx, ry, rw, rh)
                cs.stroke()
            }
            T_ELLIPSE -> {
                rgb(cs, a.color, true)
                cs.setLineWidth(a.width)
                val k = 0.5522847498f
                val cx = rx + rw / 2f
                val cy = ry + rh / 2f
                val ex = rw / 2f
                val ey = rh / 2f
                cs.moveTo(cx + ex, cy)
                cs.curveTo(cx + ex, cy + k * ey, cx + k * ex, cy + ey, cx, cy + ey)
                cs.curveTo(cx - k * ex, cy + ey, cx - ex, cy + k * ey, cx - ex, cy)
                cs.curveTo(cx - ex, cy - k * ey, cx - k * ex, cy - ey, cx, cy - ey)
                cs.curveTo(cx + k * ex, cy - ey, cx + ex, cy - k * ey, cx + ex, cy)
                cs.stroke()
            }
            T_UNDERLINE, T_STRIKE -> {
                rgb(cs, a.color, true)
                cs.setLineWidth(a.width)
                val v = if (a.kind == T_UNDERLINE) v1 else (v0 + v1) / 2f
                cs.moveTo(g.mx(u0, v), g.my(u0, v))
                cs.lineTo(g.mx(u1, v), g.my(u1, v))
                cs.stroke()
            }
            T_LINE, T_ARROW -> {
                rgb(cs, a.color, true)
                cs.setLineWidth(a.width)
                cs.setLineCapStyle(1)
                cs.moveTo(g.mx(a.x0, a.y0), g.my(a.x0, a.y0))
                cs.lineTo(g.mx(a.x1, a.y1), g.my(a.x1, a.y1))
                cs.stroke()
                if (a.kind == T_ARROW) {
                    for (p in a.arrowHead()) {
                        cs.moveTo(g.mx(a.x1, a.y1), g.my(a.x1, a.y1))
                        cs.lineTo(g.mx(p.x, p.y), g.my(p.x, p.y))
                        cs.stroke()
                    }
                }
            }
        }
        cs.restoreGraphicsState()
    }

    private fun drawImage(doc: PDDocument, cs: PDPageContentStream, a: AImage, g: Geo) {
        val img = if (a.kind == T_IMAGE) JPEGFactory.createFromImage(doc, a.bmp, 0.9f) else LosslessFactory.createFromImage(doc, a.bmp)
        val du = dirU(g.rot)
        val dv = dirV(g.rot)
        // image x-axis follows display +u, image y-axis (up) follows display -v
        val ax = a.w * du.first
        val ay = a.w * du.second
        val cx = -a.h * dv.first
        val cy = -a.h * dv.second
        val ox = g.mx(a.x, a.y + a.h)
        val oy = g.my(a.x, a.y + a.h)
        cs.saveGraphicsState()
        cs.transform(Matrix(ax, ay, cx, cy, ox, oy))
        cs.drawImage(img, 0f, 0f, 1f, 1f)
        cs.restoreGraphicsState()
    }
}
