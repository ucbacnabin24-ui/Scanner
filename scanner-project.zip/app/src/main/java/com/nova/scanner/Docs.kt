package com.nova.scanner

import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Page separators used inside the editable OCR text. */
object OcrText {
    fun header(n: Int): String = "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 Page $n \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n\n"

    private val rx = Regex("\\n*\u2500{8} Page \\d+ \u2500{8}\\n*")

    fun split(text: String): List<String> {
        val parts = text.split(rx).map { it.trim('\n', '\r') }
        val nonEmpty = parts.filter { it.isNotEmpty() }
        return if (nonEmpty.isEmpty()) listOf("") else nonEmpty
    }
}

/** Writes a real .docx (Office Open XML) with no external library. */
object DocxWriter {
    private const val RPR =
        "<w:rPr><w:rFonts w:ascii=\"Calibri\" w:hAnsi=\"Calibri\" w:cs=\"Nirmala UI\"/><w:sz w:val=\"24\"/><w:szCs w:val=\"24\"/></w:rPr>"

    private fun esc(s: String): String {
        val sb = StringBuilder(s.length + 16)
        for (ch in s) {
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '\t' || ch.code >= 0x20 -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun para(line: String): String =
        if (line.isEmpty()) "<w:p/>"
        else "<w:p><w:r>$RPR<w:t xml:space=\"preserve\">${esc(line)}</w:t></w:r></w:p>"

    fun write(out: File, pages: List<String>): Boolean {
        return try {
            val body = StringBuilder()
            pages.forEachIndexed { pi, text ->
                if (pi > 0) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
                for (line in text.replace("\r\n", "\n").split("\n")) body.append(para(line))
            }
            val document = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>" +
                body +
                "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
                "<w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/>" +
                "</w:sectPr></w:body></w:document>"
            val types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                "</Types>"
            val rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
                "</Relationships>"
            ZipOutputStream(FileOutputStream(out)).use { z ->
                fun put(name: String, data: String) {
                    z.putNextEntry(ZipEntry(name))
                    z.write(data.toByteArray(Charsets.UTF_8))
                    z.closeEntry()
                }
                put("[Content_Types].xml", types)
                put("_rels/.rels", rels)
                put("word/document.xml", document)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}

/** Text -> PDF using Android's own text layout (supports Bangla if the phone has the font). */
object TextPdf {
    private const val PW = 595
    private const val PH = 842
    private const val MARGIN = 48

    fun write(out: File, pages: List<String>): Boolean {
        val doc = PdfDocument()
        return try {
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
            paint.textSize = 12f
            paint.color = Color.BLACK
            val width = PW - 2 * MARGIN
            val usable = PH - 2 * MARGIN
            var pageNo = 1
            for (text in pages) {
                val t = if (text.isEmpty()) " " else text
                val layout = StaticLayout.Builder.obtain(t, 0, t.length, paint, width)
                    .setLineSpacing(3f, 1f)
                    .build()
                var start = 0
                while (true) {
                    val topY = layout.getLineTop(start)
                    var end = start
                    while (end < layout.lineCount && layout.getLineBottom(end) - topY <= usable) end++
                    if (end == start) end = start + 1
                    val page = doc.startPage(PdfDocument.PageInfo.Builder(PW, PH, pageNo).create())
                    val c = page.canvas
                    c.save()
                    c.translate(MARGIN.toFloat(), (MARGIN - topY).toFloat())
                    c.clipRect(0f, topY.toFloat(), width.toFloat(), layout.getLineBottom(end - 1).toFloat())
                    layout.draw(c)
                    c.restore()
                    doc.finishPage(page)
                    pageNo++
                    start = end
                    if (start >= layout.lineCount) break
                }
            }
            FileOutputStream(out).use { doc.writeTo(it) }
            true
        } catch (e: Exception) {
            false
        } finally {
            doc.close()
        }
    }
}

object Net {
    fun download(url: String, dest: File, onPct: (Int) -> Unit): Boolean {
        val tmp = File(dest.parentFile, dest.name + ".part")
        return try {
            dest.parentFile?.mkdirs()
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 20000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            if (c.responseCode != 200) return false
            val total = c.contentLengthLong
            c.inputStream.use { i ->
                FileOutputStream(tmp).use { o ->
                    val buf = ByteArray(32768)
                    var done = 0L
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        done += n
                        if (total > 0) onPct((done * 100 / total).toInt())
                    }
                }
            }
            dest.delete()
            tmp.renameTo(dest)
        } catch (e: Exception) {
            tmp.delete()
            false
        }
    }
}
