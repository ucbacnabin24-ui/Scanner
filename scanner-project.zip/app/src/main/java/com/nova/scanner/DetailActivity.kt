package com.nova.scanner

import android.content.ContentValues
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class DetailActivity : AppCompatActivity() {

    private var scan: Scan? = null
    private lateinit var titleView: TextView
    private lateinit var subView: TextView
    private lateinit var rv: RecyclerView

    private val savePdfLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
            val pdf = scan?.pdf
            if (uri != null && pdf != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { o -> pdf.inputStream().use { it.copyTo(o) } }
                    toast("PDF saved")
                } catch (e: Exception) {
                    toast("Could not save PDF")
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("id", -1L)
        scan = ScanStore.find(this, id)
        if (scan == null) {
            finish()
            return
        }
        buildUi()
        bind()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#121212"))

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(6), dp(10), dp(6), dp(2))
        header.addView(icon("\u2190") { finish() })
        titleView = TextView(this)
        titleView.setTextColor(Color.WHITE)
        titleView.textSize = 18f
        titleView.typeface = Typeface.DEFAULT_BOLD
        titleView.maxLines = 1
        titleView.ellipsize = TextUtils.TruncateAt.END
        header.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(icon("\u270E") { renameScan() })
        header.addView(icon("\uD83D\uDDD1") { deleteScan() })
        root.addView(header)

        subView = TextView(this)
        subView.setTextColor(Color.parseColor("#9CA3AF"))
        subView.textSize = 12f
        subView.setPadding(dp(18), 0, dp(18), dp(6))
        root.addView(subView)

        rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        root.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(8), dp(8), dp(8), dp(10))
        bar.addView(action("\uD83D\uDCE4 Share", Color.parseColor("#16A34A")) { scan?.let { Actions.shareDialog(this, it) } }, weight())
        bar.addView(action("\uD83D\uDCBE Save PDF", Color.parseColor("#2563EB")) { savePdf() }, weight())
        bar.addView(action("\uD83D\uDDBC Save images", Color.parseColor("#7C3AED")) { saveImages() }, weight())
        root.addView(bar)

        setContentView(root)
    }

    private fun weight(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(4), 0, dp(4), 0)
        return lp
    }

    private fun icon(t: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 22f
        v.setTextColor(Color.WHITE)
        v.gravity = Gravity.CENTER
        v.setPadding(dp(12), dp(8), dp(12), dp(8))
        v.setOnClickListener { onClick() }
        return v
    }

    private fun action(label: String, color: Int, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 13f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(6), dp(14), dp(6), dp(14))
        t.background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(12).toFloat()
        }
        t.setOnClickListener { onClick() }
        return t
    }

    private fun bind() {
        val s = scan ?: return
        titleView.text = s.name
        val n = s.pages.size
        subView.text = "$n page" + (if (n == 1) "" else "s") +
            (s.pdf?.let { "  \u2022  PDF " + fmtSize(it.length()) } ?: "")
        rv.adapter = PageAdapter(s.pages)
    }

    private fun renameScan() {
        val s = scan ?: return
        Actions.rename(this, s) {
            scan = ScanStore.find(this, s.id)
            bind()
        }
    }

    private fun deleteScan() {
        val s = scan ?: return
        Actions.delete(this, s) { finish() }
    }

    private fun savePdf() {
        val s = scan ?: return
        if (s.pdf == null) {
            toast("No PDF found")
            return
        }
        savePdfLauncher.launch(safeName(s.name) + ".pdf")
    }

    private fun saveImages() {
        val s = scan ?: return
        if (Build.VERSION.SDK_INT < 29) {
            toast("On this Android version use Share \u2192 Save to Gallery")
            return
        }
        var n = 0
        s.pages.forEachIndexed { i, f ->
            try {
                val cv = ContentValues()
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, safeName(s.name) + "_" + (i + 1) + ".jpg")
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NovaScanner")
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                    n++
                }
            } catch (e: Exception) {
                // skip this page
            }
        }
        toast("$n image(s) saved to Pictures/NovaScanner")
    }
}

class PageAdapter(private val pages: List<File>) : RecyclerView.Adapter<PageAdapter.VH>() {

    class VH(val iv: ImageView) : RecyclerView.ViewHolder(iv)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context
        val iv = ImageView(c)
        iv.adjustViewBounds = true
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setBackgroundColor(Color.parseColor("#1E1E1E"))
        iv.minimumHeight = c.dp(320)
        val lp = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = c.dp(10)
        iv.layoutParams = lp
        return VH(iv)
    }

    override fun getItemCount(): Int = pages.size

    override fun onBindViewHolder(h: VH, position: Int) {
        Thumbs.load(h.iv.context, pages[position], h.iv, 1600)
    }
}
