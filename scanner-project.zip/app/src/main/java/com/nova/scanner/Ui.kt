package com.nova.scanner

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

val BG: Int = Color.parseColor("#121212")
val GRAY: Int = Color.parseColor("#9CA3AF")
val GREEN: Int = Color.parseColor("#16A34A")
val BLUE: Int = Color.parseColor("#2563EB")
val PURPLE: Int = Color.parseColor("#7C3AED")
val ORANGE: Int = Color.parseColor("#EA580C")
val CARD: Int = Color.parseColor("#1E1E1E")
const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.roundBg(color: Int, radiusDp: Int): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(radiusDp).toFloat()
    return g
}

fun Context.iconBtn(t: String, onClick: () -> Unit): TextView {
    val v = TextView(this)
    v.text = t
    v.textSize = 22f
    v.setTextColor(Color.WHITE)
    v.gravity = Gravity.CENTER
    v.setPadding(dp(12), dp(8), dp(12), dp(8))
    v.setOnClickListener { onClick() }
    return v
}

fun Context.chip(label: String, onClick: () -> Unit): TextView {
    val t = TextView(this)
    t.text = label
    t.textSize = 13f
    t.setTextColor(Color.WHITE)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(9), dp(14), dp(9))
    t.background = roundBg(Color.parseColor("#2C2C2C"), 18)
    t.setOnClickListener { onClick() }
    return t
}

fun Context.bigButton(label: String, color: Int, onClick: () -> Unit): TextView {
    val t = TextView(this)
    t.text = label
    t.textSize = 14f
    t.typeface = Typeface.DEFAULT_BOLD
    t.setTextColor(Color.WHITE)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(8), dp(14), dp(8), dp(14))
    t.background = roundBg(color, 12)
    t.setOnClickListener { onClick() }
    return t
}

/** Back arrow + title. Returns the row and the title TextView. */
fun Context.headerRow(title: String, onBack: () -> Unit): Pair<LinearLayout, TextView> {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dp(6), dp(10), dp(6), dp(4))
    row.addView(iconBtn("\u2190") { onBack() })
    val tv = TextView(this)
    tv.text = title
    tv.textSize = 20f
    tv.typeface = Typeface.DEFAULT_BOLD
    tv.setTextColor(Color.WHITE)
    tv.maxLines = 1
    tv.ellipsize = android.text.TextUtils.TruncateAt.END
    row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
    return Pair(row, tv)
}

fun Context.chipScroll(chips: List<View>): HorizontalScrollView {
    val s = HorizontalScrollView(this)
    s.isHorizontalScrollBarEnabled = false
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.setPadding(dp(10), dp(6), dp(10), dp(6))
    for (c in chips) {
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.rightMargin = dp(8)
        row.addView(c, lp)
    }
    s.addView(row)
    return s
}

fun AppCompatActivity.chooseDialog(title: String, labels: Array<String>, current: Int, onPick: (Int) -> Unit) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setSingleChoiceItems(labels, current) { d, i ->
            d.dismiss()
            onPick(i)
        }
        .show()
}

/** Runs [work] on a background thread behind a progress dialog; [done] runs on the UI thread. */
fun <T : Any> AppCompatActivity.runBusy(
    msg: String,
    work: ((String) -> Unit) -> T?,
    done: (T?) -> Unit
) {
    val dlg = AlertDialog.Builder(this).setMessage(msg).setCancelable(false).show()
    Thread {
        val r: T? = try {
            work { m -> runOnUiThread { dlg.setMessage(m) } }
        } catch (e: Throwable) {
            null
        }
        runOnUiThread {
            try {
                dlg.dismiss()
            } catch (e: Exception) {
                // ignore
            }
            if (!isFinishing) done(r)
        }
    }.start()
}
