package com.nova.scanner

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** AI-style enhance: automatic modes + manual sliders, hold the image to compare with the original. */
class EnhanceActivity : AppCompatActivity() {

    private val uris = ArrayList<Uri>()
    private var idx = 0
    private val params = EnhanceParams()
    private lateinit var iv: ImageView
    private lateinit var pageLabel: TextView
    private lateinit var modeChip: TextView
    private lateinit var shadowChip: TextView
    private lateinit var upChip: TextView
    private var srcBmp: Bitmap? = null
    private var outBmp: Bitmap? = null
    @Volatile
    private var gen = 0
    private var baseName = "Enhanced"

    private val picker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { list ->
        if (list.isNotEmpty()) {
            uris.clear()
            uris.addAll(list)
            baseName = "Enhanced"
            idx = 0
            loadCurrent()
        } else if (uris.isEmpty()) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val id = intent.getLongExtra("id", -1L)
        val s = if (id > 0) ScanStore.find(this, id) else null
        if (s != null && s.pages.isNotEmpty()) {
            s.pages.forEach { uris.add(Uri.fromFile(it)) }
            baseName = "Enhanced - " + s.name
            loadCurrent()
        } else {
            picker.launch("image/*")
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val (header, _) = headerRow("AI Enhance") { finish() }
        header.addView(chip("\uD83D\uDDBC Pick") { picker.launch("image/*") })
        header.addView(chip("\uD83D\uDCBE Save") { save() })
        root.addView(header)

        iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setBackgroundColor(Color.parseColor("#222222"))
        iv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    srcBmp?.let { iv.setImageBitmap(it) }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    outBmp?.let { iv.setImageBitmap(it) }
                    v.performClick()
                    true
                }
                else -> true
            }
        }
        root.addView(iv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val tip = TextView(this)
        tip.setTextColor(GRAY)
        tip.textSize = 11f
        tip.text = "Hold the image to see the original"
        tip.setPadding(dp(16), 0, dp(16), dp(2))
        root.addView(tip)

        pageLabel = TextView(this)
        pageLabel.setTextColor(Color.WHITE)
        pageLabel.setPadding(dp(10), dp(6), dp(10), dp(6))
        modeChip = chip("") {
            chooseDialog("Enhance mode", Enhance.modeNames, params.mode) {
                params.mode = it
                refreshChips()
                render()
            }
        }
        shadowChip = chip("") {
            params.shadow = !params.shadow
            refreshChips()
            render()
        }
        upChip = chip("") {
            params.upscale = !params.upscale
            refreshChips()
            render()
        }
        root.addView(chipScroll(listOf(
            chip("\u25C0") { if (idx > 0) { idx--; loadCurrent() } },
            pageLabel,
            chip("\u25B6") { if (idx < uris.size - 1) { idx++; loadCurrent() } },
            modeChip, shadowChip, upChip
        )))

        root.addView(slider("Brightness", -50, 50, 0) { params.brightness = it })
        root.addView(slider("Contrast", -50, 50, 0) { params.contrast = it })
        root.addView(slider("Sharpness", 0, 100, params.sharpen) { params.sharpen = it })
        root.addView(slider("Noise reduction", 0, 2, 0) { params.denoise = it })
        setContentView(root)
        refreshChips()
    }

    private fun slider(label: String, min: Int, max: Int, init: Int, onSet: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(14), 0, dp(14), 0)
        val tv = TextView(this)
        tv.setTextColor(GRAY)
        tv.textSize = 12f
        tv.text = "$label: $init"
        row.addView(tv, LinearLayout.LayoutParams(dp(130), WRAP))
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = init - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                tv.text = "$label: ${p + min}"
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {
                onSet(s.progress + min)
                render()
            }
        })
        row.addView(sb, LinearLayout.LayoutParams(0, WRAP, 1f))
        return row
    }

    private fun refreshChips() {
        modeChip.text = "\u2728 " + Enhance.modeNames[params.mode]
        shadowChip.text = "Shadow removal: " + if (params.shadow) "ON" else "OFF"
        upChip.text = "Upscale \u00D72: " + if (params.upscale) "ON" else "OFF"
    }

    private fun loadCurrent() {
        if (uris.isEmpty()) return
        pageLabel.text = "${idx + 1} / ${uris.size}"
        val u = uris[idx]
        Thread {
            val b = ImageUtil.decode(applicationContext, u, 1100)
            runOnUiThread {
                srcBmp = b
                render()
            }
        }.start()
    }

    private fun render() {
        val s = srcBmp ?: return
        val g = ++gen
        val p = params.copy()
        Thread {
            val o = try {
                Enhance.apply(s, p, 1400)
            } catch (e: OutOfMemoryError) {
                null
            }
            runOnUiThread {
                if (g == gen && o != null) {
                    outBmp = o
                    iv.setImageBitmap(o)
                }
            }
        }.start()
    }

    private fun save() {
        if (uris.isEmpty()) {
            toast("Pick images first")
            return
        }
        val list = ArrayList(uris)
        val p = params.copy()
        runBusy("Enhancing\u2026", { prog ->
            val resIdx = Quality.resIndex(this)
            val budget = Quality.budgetPerPage(this, list.size)
            val enc = ArrayList<EncodedPage>()
            list.forEachIndexed { i, u ->
                prog("Enhancing image ${i + 1} / ${list.size}\u2026")
                val src = ImageUtil.decode(this, u, 3200)
                if (src != null) {
                    val out = Enhance.apply(src, p, 3200)
                    if (out !== src) src.recycle()
                    enc.add(Quality.encodeBitmapScaled(out, resIdx, budget))
                    out.recycle()
                }
            }
            prog("Saving\u2026")
            ScanStore.createFromPages(this, enc, PdfLayout(0f, 0f, 0f, 0), baseName + " " + defaultName(System.currentTimeMillis()).removePrefix("Scan "))
        }, { s ->
            if (s == null) {
                toast("Could not save")
            } else {
                startActivity(Intent(this, DetailActivity::class.java).putExtra("id", s.id))
                finish()
            }
        })
    }
}
